<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='epp.package.jee' timestamp='1380812002852'>
  <properties size='12'>
    <property name='org.eclipse.equinox.p2.installFolder' value='/Volumes/FDT/FDT.app/Contents/FDT'/>
    <property name='org.eclipse.equinox.p2.cache' value='/Users/paulscarrone/.eclipse/org.eclipse.platform_4.2.0_54488603'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.nl=en_US,osgi.ws=cocoa,osgi.arch=x86_64,osgi.os=macosx'/>
    <property name='eclipse.touchpoint.launcherName' value='eclipse'/>
    <property name='org.eclipse.equinox.p2.cache.extensions' value='file:/E:/FDT_Work/TargetTempMacOS/FDT/.eclipseextension|file:/E:/FDT_Work/TargetTempMacOS/FDT/configuration/org.eclipse.osgi/bundles/308/data/listener_1925729951/'/>
    <property name='org.eclipse.equinox.p2.surrogate' value='true'/>
    <property name='org.eclipse.equinox.p2.shared.timestamp' value='1377607131589'/>
    <property name='org.eclipse.equinox.p2.cache.shared' value='/Volumes/FDT/FDT.app/Contents/FDT'/>
    <property name='org.eclipse.equinox.p2.configurationFolder' value='/Users/paulscarrone/.eclipse/org.eclipse.platform_4.2.0_54488603/configuration'/>
    <property name='org.eclipse.equinox.p2.launcherConfiguration' value='/Users/paulscarrone/.eclipse/org.eclipse.platform_4.2.0_54488603/configuration/eclipse.ini.ignored'/>
  </properties>
  <units size='8'>
    <unit id='SharedProfile_epp.package.jee' version='1.0.0.1377607131589' singleton='false' generation='2'>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Shared profile'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='SharedProfile_epp.package.jee' version='1.0.0.1377607131589'/>
      </provides>
      <requires size='1165'>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.mysql&apos;, version(&apos;1.0.3.v201205252211&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws_ui.feature.feature.group&apos;, version(&apos;3.4.0.v201203150412-7I7CFkWEtEoXHw284K6n3-oEz-uotfK5qz-68n73&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.modelbase.sql.edit&apos;, version(&apos;1.0.1.v201107221519&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.persistence.dbws.builder&apos;, version(&apos;2.4.0.v20120604-r11619&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.ddlgen.ui&apos;, version(&apos;1.0.2.v201201131129&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.addons.swt&apos;, version(&apos;0.10.1.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.db2.zseries.ui&apos;, version(&apos;1.0.2.v201202100836&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.common.feature.feature.group&apos;, version(&apos;1.2.0.v201203150000-66-AkF7BF7PBN7778&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.ui&apos;, version(&apos;1.0.403.v201004211805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf&apos;, version(&apos;3.1.300.v20120319-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.util&apos;, version(&apos;1.0.400.v20120522-2049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.emfworkbench.integration&apos;, version(&apos;1.2.101.v201107140600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml_userdoc.feature.feature.jar&apos;, version(&apos;3.3.0.v201102071641-50FYwAkF7B77UBZFDBL&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery.feature.feature.group&apos;, version(&apos;1.0.100.v20120524-0542-4-Bh9oB58A5N9L28PCQ&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.user.ui.feature.jar&apos;, version(&apos;2.2.0.v20120524-0542-62DG9JXTlShQUbcP-bhrkOUjZ_P7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.cxf.feature.feature.jar&apos;, version(&apos;1.1.0.v201201312103-7H79FHxFAKlbotH5e9l3vAA6MBG&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.model.workbench&apos;, version(&apos;0.10.1.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core&apos;, version(&apos;2.2.0.v20120430-0525&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.navigator.ui&apos;, version(&apos;1.1.600.v201203142300&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.persistence&apos;, version(&apos;2.0.4.v201112161009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.generic.ui&apos;, version(&apos;1.0.505.v20100428&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.ui&apos;, version(&apos;3.8.0.v20120530-1753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.frameworks&apos;, version(&apos;1.2.200.v201203141800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sqlite.ui&apos;, version(&apos;1.0.0.v201107221507&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator&apos;, version(&apos;3.5.200.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl.jaxp.debug.ui&apos;, version(&apos;1.0.200.v201103081922&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server_adapters.ext.feature.feature.group&apos;, version(&apos;3.3.100.v20110810_1722-777HFL5CcNBDmBfJVFHJD6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.dom&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.finfo&apos;, version(&apos;1.5.1.v200906161800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.enterprise_core.feature.feature.jar&apos;, version(&apos;3.4.0.v201108110300-52FShAkF7BA8O8J9OC8&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl.ui&apos;, version(&apos;1.1.300.v201204101539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench&apos;, version(&apos;3.103.0.v20120530-1824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.wsdl&apos;, version(&apos;1.5.1.v201012040544&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.wsdl&apos;, version(&apos;1.6.2.v201012040545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.oda.cshelp&apos;, version(&apos;1.1.1.v201107221500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.wsdl.validation&apos;, version(&apos;1.1.600.v201203081939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core&apos;, version(&apos;3.8.1.v20120531-0637&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.html.core&apos;, version(&apos;1.1.600.v201204260100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.converter.feature.group&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.cxf.consumption.core&apos;, version(&apos;1.0.200.v201201312103&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxws.dom.integration&apos;, version(&apos;1.0.200.v201109042201&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.useractions.feature.group&apos;, version(&apos;1.1.400.201205300905-31FBV773573D933L3D&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ingres.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-540AkF78Z7UCRAQDB&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xerces&apos;, version(&apos;2.9.0.v201101211617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxws.core&apos;, version(&apos;1.0.200.v201204172145&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.db2.iseries.dbdefinition&apos;, version(&apos;1.0.3.v201107221502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform&apos;, version(&apos;4.2.0.v201205311500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server_adapters.feature.feature.group&apos;, version(&apos;3.2.200.v20120517_1442-20A77w31231628a2553&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.oda.designer.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-3368s7356485C59AB&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.lang&apos;, version(&apos;2.1.0.v201005080500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.lang&apos;, version(&apos;2.6.0.v201205030909&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help&apos;, version(&apos;3.6.0.v20120521-2344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.common.branding&apos;, version(&apos;1.2.0.v201203150000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.result.ui&apos;, version(&apos;1.1.2.v201110010535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.snippets&apos;, version(&apos;1.2.200.v201204260225&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.feature.jar&apos;, version(&apos;1.1.1.I20110907-0947&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.feature.jar&apos;, version(&apos;3.8.0.v20120525-1249-7c7vFitFFt6Zr5_yF0M3KRI&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.tomcat.core&apos;, version(&apos;1.1.400.v20120418_1501&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.ssh&apos;, version(&apos;2.1.100.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.modelbase.sql.xml.query&apos;, version(&apos;1.0.2.v201201131123&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.preferences&apos;, version(&apos;3.5.0.v20120522-1841&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ejb.doc.user&apos;, version(&apos;1.1.301.v201105130956&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.bugzilla_feature.feature.group&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl.xalan&apos;, version(&apos;1.0.100.v201103081922&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.ui.doc.user&apos;, version(&apos;1.0.500.v201005192218&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.help&apos;, version(&apos;1.5.0.v200906020553&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sap.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-540AkF7AJ7YEJBU7S&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.consumer&apos;, version(&apos;3.2.5.v201109151100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.bugzilla_feature.feature.jar&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.core&apos;, version(&apos;2.9.1.v201101211721&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.creation.ejb.ui&apos;, version(&apos;1.0.201.v201004211805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.cxf.creation.ui&apos;, version(&apos;1.0.200.v201204221838&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.http.ui&apos;, version(&apos;1.0.200.v20090113&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.intro.feature.jar&apos;, version(&apos;1.10.0.v201201161512-26-7w312116392911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.ftp.feature.jar&apos;, version(&apos;3.1.0.201205300905-782FBV8377A6FC79ODI4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.ui.feature.group&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.oda.xml.ui&apos;, version(&apos;1.2.3.v201112071047&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.editor.feature.jar&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;epp.package.jee&apos;, version(&apos;1.5.0.20120602-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsf.common.runtime&apos;, version(&apos;1.1.0.v20100510&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-7J9Q0BWxeMcYB5KWfz-eG7qiq-sX&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.db.generic&apos;, version(&apos;1.0.1.v201107221459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.command.env&apos;, version(&apos;1.0.409.v201004211805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.ui&apos;, version(&apos;3.3.0.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.oda.ws.ui&apos;, version(&apos;1.2.4.v201203221631&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxws.ui&apos;, version(&apos;1.0.200.v201204221614&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.ui&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.ui.infopop&apos;, version(&apos;1.0.400.v201004292007&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.jca.ui&apos;, version(&apos;1.1.400.v201004150700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.fproj.feature.group&apos;, version(&apos;3.4.0.v201202292300-377F8N8s735555393B7B&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws.service.policy&apos;, version(&apos;1.0.303.v201009221810&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingcocoa.macosx.x86_64org.eclipse.equinox.ds&apos;, version(&apos;4.2.0.I20120531-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.core&apos;, version(&apos;1.2.0.v200908252030&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.monitor.feature.group&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.lib.antlr&apos;, version(&apos;3.1.0.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.tasks.ui&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.servlet&apos;, version(&apos;3.0.0.v201112011016&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.web_core.feature.feature.group&apos;, version(&apos;3.4.0.v201111022313-7Q7EGVtFE9LeAJKiyp_z-Rsyivz-0sSxz003877&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.ui&apos;, version(&apos;1.1.300.v201205022014&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_ui.feature.feature.group&apos;, version(&apos;3.3.100.v20110810_1722-7B7AFGHAtMcLXxbGc-IjRefCA84&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.edit.feature.group&apos;, version(&apos;1.2.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatesite&apos;, version(&apos;1.0.400.v20120412-1615&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.dbws.eclipselink.feature.feature.group&apos;, version(&apos;1.1.100.v201203150000-797EBiCcNBHKCZEYAwHIF5L&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.rcp.feature.feature.group&apos;, version(&apos;1.1.0.v20120524-0542-785EoBqNKNYxiX2sUgC_BYz-CdiT&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.view.feature.group&apos;, version(&apos;2.3.0.201205300905-32-312316411A16&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.server&apos;, version(&apos;8.1.3.v20120522&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.feature.group&apos;, version(&apos;3.8.0.201206011524&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingepp.package.jee.config.cocoa.macosx.x86_64&apos;, version(&apos;1.5.0.20120602-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.configuration.macosx&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.consumption&apos;, version(&apos;1.0.700.v201204102147&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.converter&apos;, version(&apos;2.5.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl.doc&apos;, version(&apos;1.0.100.v201004292007&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.web.ui&apos;, version(&apos;1.0.501.v201205241808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sqlite.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-542AkF7AJ7SAKAPBF&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.sql.ui&apos;, version(&apos;1.0.1.v201201270735&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxws.utils&apos;, version(&apos;1.0.200.v201201032002&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.asdoc&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.generic.jonas&apos;, version(&apos;1.5.205.v200805140145&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.axis2.creation.ui&apos;, version(&apos;1.0.104.v201004211805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.identity.core&apos;, version(&apos;1.0.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sap.maxdb.ui&apos;, version(&apos;1.0.0.v201107221507&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.workbench&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.cxf.consumption.ui&apos;, version(&apos;1.0.200.v201201312103&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.ftp.feature.group&apos;, version(&apos;3.1.0.201205300905-782FBV8377A6FC79ODI4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.ejb.annotations.xdoclet&apos;, version(&apos;1.2.200.v201103302125&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.web_core.feature.feature.jar&apos;, version(&apos;3.4.0.v201111022313-7Q7EGVtFE9LeAJKiyp_z-Rsyivz-0sSxz003877&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.xpath.core&apos;, version(&apos;1.3.0.v201108312136&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide.application&apos;, version(&apos;1.0.400.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.modelbase.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-7707CCcNBHIEQJXHUNf&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.core.feature.group&apos;, version(&apos;3.4.0.201205300905-7a7NFm-7sResSX4RTNSW&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.mozilla.javascript&apos;, version(&apos;1.7.2.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.schemaobjecteditor.ui&apos;, version(&apos;1.1.1.200810071&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.dbdefinition.genericJDBC&apos;, version(&apos;1.0.1.v201107221459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-7H7C7QCcNBHKDYJgFYLT&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.feature.jar&apos;, version(&apos;4.2.0.v20120528-1648-7IAPA7BrHQicRoQXOz0Obz-blRCA&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.shells.ssh&apos;, version(&apos;2.1.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xml.resolver&apos;, version(&apos;1.2.0.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sqlite.dbdefinition&apos;, version(&apos;1.0.2.v201206010441&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef&apos;, version(&apos;3.8.0.201206011524&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.swcOutline&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jpa.db.ui&apos;, version(&apos;2.0.0.v201104110000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.web_userdoc.feature.feature.jar&apos;, version(&apos;3.3.0.v201102200555-31Eo8s734B3E4H7799&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.profiler&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.launching.ui.macosx&apos;, version(&apos;1.0.100.v20120523-1953&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ejb.ui&apos;, version(&apos;1.1.700.v201201190500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.ui.doc.user&apos;, version(&apos;1.1.400.v201104111553&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.feature.jar&apos;, version(&apos;1.1.0.v20120524-0542-8297Fm3FWmE7h3AXyBchSbZ&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.ddlgen.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-7A-78F7RZHQSIqWjN1Zr&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.jdbc.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-4-29oB5885QBB8HKW&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.compiler.tool&apos;, version(&apos;1.0.101.v20120522-1651&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp&apos;, version(&apos;4.2.0.v201205311500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.textile.ui&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.confluence.core&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.files.local&apos;, version(&apos;2.1.300.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.converter.feature.jar&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.ide.ini.cocoa.macosx.x86_64&apos;, version(&apos;4.2.0.I20120531-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.files.dstore&apos;, version(&apos;2.1.300.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.web_ui.feature.feature.jar&apos;, version(&apos;3.4.0.v201111022313-7F7DFSgC25TrkWsplelWwGPu4Ajn5UiEiyuqxZp4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.ide_feature.feature.group&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore&apos;, version(&apos;2.6.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.team_feature.feature.group&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.ddl.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-279-78B089G8S_IRTJrXkO2_s&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.index.core&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.ssh.feature.group&apos;, version(&apos;2.1.100.201205300905-308Z312316411A16&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.ssh.feature.jar&apos;, version(&apos;2.1.100.201205300905-308Z312316411A16&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.debugger.adapter&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.common.eclipselink.feature.feature.group&apos;, version(&apos;1.2.0.v201203150000-33-8s7357395D3333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2xml.ui&apos;, version(&apos;2.6.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.xml.ws&apos;, version(&apos;2.1.0.v200902101523&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.jdbc.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-4-29oB5885QBB8HKW&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views&apos;, version(&apos;3.6.100.v20120521-2329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.common.eclipselink.feature.feature.jar&apos;, version(&apos;1.2.0.v201203150000-33-8s7357395D3333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.preview.adapter&apos;, version(&apos;1.1.200.v20120517_1442&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.common&apos;, version(&apos;3.6.100.v20120522-1841&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.axis.ui.doc.user&apos;, version(&apos;1.1.100.v201005192217&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;ch.qos.logback.core&apos;, version(&apos;1.0.0.v20111214-2030&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.macosx&apos;, version(&apos;1.100.200.v20120522-2049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.editor.feature.group&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.xpath2.processor.feature.feature.group&apos;, version(&apos;2.0.100.v201203131922-7A7K0CcNBGPCTJ_FUOb&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.wsi&apos;, version(&apos;1.0.500.v201203081939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.doc.user&apos;, version(&apos;1.7.0.20090521092446&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2ecore.editor&apos;, version(&apos;2.5.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.web_core.feature.feature.jar&apos;, version(&apos;3.4.0.v201203141800-7E7HFSgAJz-mw9oH21HGMpHiKb_kVAz0D&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.uriresolver&apos;, version(&apos;1.2.0.v201203071939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.command.env.infopop&apos;, version(&apos;1.0.100.v200805301544&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.dtd.core&apos;, version(&apos;1.1.600.v201205171933&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.runtime.compatibility.auth&apos;, version(&apos;3.2.200.v20110110&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util.gui&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher&apos;, version(&apos;1.3.0.v20120522-1813&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.launching&apos;, version(&apos;1.0.200.v20120530-1204&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.apache.derby.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-77798fBmKDQ2MoTTLwdv9ILX&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.feature.jar&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server_ui.feature.feature.jar&apos;, version(&apos;3.4.0.v20120503_1042-7A77FHr9xFcC2CFLZBCJMHLg7D64&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench3&apos;, version(&apos;0.12.0.v20120521-2329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.db2.iseries.ui&apos;, version(&apos;1.0.2.v201202100836&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.commands&apos;, version(&apos;0.10.1.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.jcraft.jsch&apos;, version(&apos;0.1.46.v201205102330&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.web_userdoc.feature.feature.jar&apos;, version(&apos;3.4.0.v201111022313-2107w31211938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.persistence.antlr&apos;, version(&apos;3.2.0.v201206041011&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.modulecore&apos;, version(&apos;1.2.200.v201204190200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.xml.rpc&apos;, version(&apos;1.1.0.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jpa.feature.feature.group&apos;, version(&apos;3.2.0.v201203150000-7S7K8aFBBoPaoQM_ZRKUVF5L&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.parsers.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-623BgJ9EE9ZJRDZLA&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.build&apos;, version(&apos;3.8.0.v20120523-1555&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.monitor.ui&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.text&apos;, version(&apos;3.8.0.v20120531-0600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl.core&apos;, version(&apos;1.1.100.v201102270516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_userdoc.feature.feature.jar&apos;, version(&apos;3.3.0.v20110512-20DF7w312215222664&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.axis.consumption.ui&apos;, version(&apos;1.0.700.v201204181727&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.efs.ui&apos;, version(&apos;2.1.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_core.feature.feature.jar&apos;, version(&apos;3.3.100.v20110810_1722-33Et8s73563B6Ha3113&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.mortbay.jetty.util&apos;, version(&apos;6.1.23.v201012071420&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director&apos;, version(&apos;2.2.0.v20120524-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;a.jre.javase&apos;, version(&apos;1.6.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem&apos;, version(&apos;1.3.200.v20120522-2012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.common.feature.feature.group&apos;, version(&apos;1.5.0.20120202-1420&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.twiki.core&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.dstore.core&apos;, version(&apos;3.3.100.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity&apos;, version(&apos;1.2.5.v201205230922&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.services.ssh&apos;, version(&apos;3.2.0.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.cvs.ssh2&apos;, version(&apos;3.2.300.v20120522-1148&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.feature.jar&apos;, version(&apos;3.8.0.201206011524&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.common.core&apos;, version(&apos;1.2.0.v201205240000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.externaltools&apos;, version(&apos;1.0.100.v20120521-2012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.operations&apos;, version(&apos;2.2.0.v20120524-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jem.workbench&apos;, version(&apos;2.0.400.v201104251400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.ui&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.ui&apos;, version(&apos;1.4.0.v20120501_1141&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata.repository&apos;, version(&apos;1.2.100.v20120524-1717&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.dtd.ui&apos;, version(&apos;1.0.700.v201203081826&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.repositories.feature.jar&apos;, version(&apos;1.0.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.cvs.core&apos;, version(&apos;3.3.500.v20120522-1148&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.pluggable.core&apos;, version(&apos;1.0.400.v20120522-1651&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.mysql.dbdefinition&apos;, version(&apos;1.0.4.v201109022331&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.dstore.feature.jar&apos;, version(&apos;3.4.0.201205300905-7L79FYw7VFNVFscFGMFs&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text&apos;, version(&apos;3.5.200.v20120523-1310&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.webservice&apos;, version(&apos;1.1.400.v201004110600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.sqm.core.ui&apos;, version(&apos;1.2.2.v201205240353&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.console&apos;, version(&apos;1.0.0.v20120522-1841&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.core&apos;, version(&apos;1.4.0.v20120425_2002&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsf.common&apos;, version(&apos;1.2.3.v201104061039&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws_userdoc.feature.feature.group&apos;, version(&apos;3.1.300.v201102200555-44FR79oB5855Q8IBD7G&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.doc.user&apos;, version(&apos;1.2.0.v200806052254&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.feature.jar&apos;, version(&apos;3.4.0.201205300905-7L7IFBV83omxZWwIDyHWipb2Sz-f&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.files.ftp&apos;, version(&apos;2.1.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.xpath2.processor.doc.user&apos;, version(&apos;2.0.0.v201105190326&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common_ui.feature.feature.jar&apos;, version(&apos;3.4.0.v201203141800-7C7AFeBEdhOawe9e8mNfykJqRz00Q0RT&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.telnet&apos;, version(&apos;2.1.100.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.rcp.feature.feature.jar&apos;, version(&apos;1.1.0.v20120524-0542-785EoBqNKNYxiX2sUgC_BYz-CdiT&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.sse.core&apos;, version(&apos;1.1.700.v201205171812&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.html.ui&apos;, version(&apos;1.0.700.v201201102037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.command.env.ui&apos;, version(&apos;1.1.103.v201102260635&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.fproj.feature.jar&apos;, version(&apos;3.4.0.v201202292300-377F8N8s735555393B7B&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_userdoc.feature.feature.group&apos;, version(&apos;3.3.0.v20110512-20DF7w312215222664&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.haxe.ui&apos;, version(&apos;1.0.0.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper&apos;, version(&apos;1.0.400.v20120522-2049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.persistence.jpa.jpql&apos;, version(&apos;2.0.0.v20120604-r11619&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sybase.asa.schemaobjecteditor.examples&apos;, version(&apos;2.5.0.200810071&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.common.eclipselink.core&apos;, version(&apos;1.2.0.v201203150000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jem.beaninfo.vm.common&apos;, version(&apos;2.0.300.v201004110600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jaxb.core&apos;, version(&apos;1.2.0.v201205100000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common_core.feature.feature.group&apos;, version(&apos;3.4.0.v201107190500-7B7EFMSF7RZHOjIpQz-P-QS&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt&apos;, version(&apos;0.10.1.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.persistence.dbws&apos;, version(&apos;2.4.0.v20120604-r11619&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.java&apos;, version(&apos;2.6.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.command.env.doc.user&apos;, version(&apos;1.5.300.v201005192225&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sybase.models&apos;, version(&apos;1.0.0.v201010140307&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.internet.cache&apos;, version(&apos;1.0.600.v201203071939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.syndication&apos;, version(&apos;0.9.0.v200803061811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.expressions&apos;, version(&apos;3.4.400.v20120523-2004&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.debug.crossfire&apos;, version(&apos;1.0.200.v201205241852&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.velocity&apos;, version(&apos;1.5.0.v200905192330&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.frameworks.ui&apos;, version(&apos;1.2.200.v201203150300&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.universal&apos;, version(&apos;3.2.600.v20120521-2344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.ui&apos;, version(&apos;1.2.3.v201205240353&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.feature.group&apos;, version(&apos;1.1.1.I20110907-0947&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.extension.feature.group&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wtp.epp.package.jee.intro&apos;, version(&apos;1.3.0.v201006142040&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.context_feature.feature.group&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml_userdoc.feature.feature.group&apos;, version(&apos;3.3.0.v201102071641-50FYwAkF7B77UBZFDBL&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde&apos;, version(&apos;3.7.0.v201205311500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.discovery&apos;, version(&apos;1.0.300.v20120403_0949&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsp.core&apos;, version(&apos;1.2.500.v201203071954&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.ui&apos;, version(&apos;1.1.201.v201204101526&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.informix&apos;, version(&apos;1.0.1.v201107221502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.edit.feature.jar&apos;, version(&apos;1.2.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxws_userdoc.feature.feature.jar&apos;, version(&apos;1.0.200.v201205012246-3-DF8s73573D795LAF&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.apache.derby.ui&apos;, version(&apos;1.0.3.v201107221459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.core&apos;, version(&apos;1.1.1.I20110907-0947&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.webapp&apos;, version(&apos;3.6.100.v20120521-2344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.core&apos;, version(&apos;2.3.0.v20110329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws.infopop&apos;, version(&apos;1.0.300.v200805140230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.schemaobjecteditor&apos;, version(&apos;1.1.0.v200906022302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.widgets&apos;, version(&apos;0.12.0.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.dstore.feature.group&apos;, version(&apos;3.4.0.201205300905-7L79FYw7VFNVFscFGMFs&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.dom.smil&apos;, version(&apos;1.0.0.v200806040011&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin&apos;, version(&apos;2.0.0.v20110808-1657&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.doc.user.feature.group&apos;, version(&apos;1.10.0.v201201161512-37D-7733L3D753L7BBF&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.doc.user&apos;, version(&apos;3.8.0.v20120531-1353&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.useractions.source&apos;, version(&apos;1.1.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sybase.ase.models&apos;, version(&apos;1.0.1.v201010140307&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.command&apos;, version(&apos;0.8.0.v201108120515&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wtp.xml.capabilities&apos;, version(&apos;1.0.100.v201005102000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsf.branding&apos;, version(&apos;3.2.0.v20100522&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.schemaobjecteditor.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-4208375LG5BJ93413&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsf.facesconfig.ui&apos;, version(&apos;1.2.100.v201201111516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.ui&apos;, version(&apos;3.6.200.v20120522-1148&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.jws&apos;, version(&apos;2.0.0.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.processes.core&apos;, version(&apos;3.1.300.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security&apos;, version(&apos;1.1.100.v20120522-1841&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.xml.stream&apos;, version(&apos;1.0.1.v201004272200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.feature.jar&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.files.ssh&apos;, version(&apos;2.1.300.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.wsi.ui.doc.user&apos;, version(&apos;1.0.700.v201008122303&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.common.doc.user&apos;, version(&apos;1.7.0.20090521092446&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.common.ui&apos;, version(&apos;1.2.0.v201205150000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.common.doc.user.feature.group&apos;, version(&apos;1.10.0.v201201161512-26-311A16321A3557&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.feature.jar&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingcocoa.macosx.x86_64org.eclipse.equinox.p2.reconciler.dropins&apos;, version(&apos;4.2.0.I20120531-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.discovery.core&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.search&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml_ui.feature.feature.group&apos;, version(&apos;3.4.0.v201111021744-7H7GFeBDxumUpsl5liePhK3loz-m62J4rSz011R1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.sqlbuilder&apos;, version(&apos;1.0.3.v201107221520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.sqlbuilder.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-79-78EVVFNOGnTeK-SY&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jee.web&apos;, version(&apos;1.0.301.v201007070907&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.confluence.ui&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.event&apos;, version(&apos;1.2.200.v20120522-2049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.ui&apos;, version(&apos;1.1.1.I20110907-0947&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.cxf.doc.user&apos;, version(&apos;1.0.200.v201205231944&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.axis2.creation.core&apos;, version(&apos;1.0.106.v201004211805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.websphere.core&apos;, version(&apos;1.0.302.v20080620&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wtp.epp.package.capabilities&apos;, version(&apos;1.3.0.v201005102000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common&apos;, version(&apos;2.8.0.v20120530-0726&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsp.ui.infopop&apos;, version(&apos;1.0.200.v201004150328&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.oda.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-7A7T7CDZRDKHF_HnGjOX&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.codec&apos;, version(&apos;1.3.0.v201101211617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm&apos;, version(&apos;3.3.1.v201105211655&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.shells.telnet&apos;, version(&apos;1.2.300.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.sqleditor&apos;, version(&apos;1.0.2.v201107221520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.result&apos;, version(&apos;1.1.3.v201205310911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.uddi4j&apos;, version(&apos;2.0.5.v200805270300&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.ejb.annotations.ui&apos;, version(&apos;1.1.200.v201004290730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.shells.dstore&apos;, version(&apos;2.1.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer&apos;, version(&apos;3.2.0.v20120319-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingcocoa.macosx.x86_64org.eclipse.equinox.event&apos;, version(&apos;4.2.0.I20120531-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.profiler&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.css.core&apos;, version(&apos;1.1.600.v201204260115&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.registry&apos;, version(&apos;3.5.200.v20120522-1841&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsf.feature.feature.group&apos;, version(&apos;3.4.0.v201111022140-7E7JFBZF9JgLWZLz0U0QoZm3357&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsf.facelet.ui&apos;, version(&apos;1.0.1.v201104032306&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.ide_feature.feature.jar&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.natives&apos;, version(&apos;1.1.0.v20120524-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.feature.jar&apos;, version(&apos;3.8.0.201206011524&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.web_userdoc.feature.feature.group&apos;, version(&apos;3.4.0.v201111022313-2107w31211938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.help.ui&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin.equinox&apos;, version(&apos;1.0.400.v20120428-0117&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.oracle.dbdefinition&apos;, version(&apos;1.0.103.v201206010214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.pb&apos;, version(&apos;2.3.0.v20110329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.results.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-57B78AkF7BD7PGE9_DH&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.feature.group&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.debug.rhino&apos;, version(&apos;1.0.200.v201204241858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.feature.group&apos;, version(&apos;3.8.0.201206011524&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_ui.feature.feature.jar&apos;, version(&apos;3.3.100.v20110810_1722-7B7AFGHAtMcLXxbGc-IjRefCA84&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-7J9Q0BWxeMcYB5KWfz-eG7qiq-sX&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.source.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jsoup&apos;, version(&apos;1.6.1.v201201201356&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsp.ui&apos;, version(&apos;1.1.700.v201204260100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.property&apos;, version(&apos;1.4.100.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.internet.monitor.core&apos;, version(&apos;1.0.505.v20110419&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.enterprise&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.efs&apos;, version(&apos;2.1.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxws.dom.ui&apos;, version(&apos;1.0.0.v201004171919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.telnet.feature.group&apos;, version(&apos;2.1.100.201205300905-308Z312316411A16&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.shells.local&apos;, version(&apos;2.1.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.wsdl.ui.doc.user&apos;, version(&apos;1.0.800.v201008122303&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.flexProjectImporter&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extras.feature.feature.jar&apos;, version(&apos;1.1.0.v20120524-0542-7A6FEcDiVOTg-s_HuZrEtBYz-Cdi&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.debug.core&apos;, version(&apos;3.1.0.v201205241852&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.databinding&apos;, version(&apos;1.6.0.v20120521-2329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingepp.package.jee.application&apos;, version(&apos;1.5.0.20120602-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.debug.rhino.ui&apos;, version(&apos;1.0.100.v201202292247&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.data.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-644BgJ9ECCLFTAfMO&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions&apos;, version(&apos;0.11.0.v20120523-2004&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.feature.group&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_core.feature.feature.group&apos;, version(&apos;3.3.100.v20110810_1722-33Et8s73563B6Ha3113&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.beans&apos;, version(&apos;1.2.200.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.modulecore.ui&apos;, version(&apos;1.0.200.v201204042200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sybase.ui&apos;, version(&apos;1.0.0.v200906090452&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.feature.group&apos;, version(&apos;3.8.0.v20120525-1249-8-8nFqlFNOfwKDRF3dXMdHyBC834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.dbws.eclipselink.ui&apos;, version(&apos;1.0.200.v201203150000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jpa.ui&apos;, version(&apos;3.2.0.v201205230001&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.xdoclet.runtime&apos;, version(&apos;1.1.300.v201004280700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper.registry&apos;, version(&apos;1.0.300.v20120522-2049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxrs.ui&apos;, version(&apos;1.0.500.v201205020140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools&apos;, version(&apos;1.0.400.v20120523-2012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.feature.group&apos;, version(&apos;4.2.0.v20120528-1648-9JF7BHV8FyMteji0MoOeOuU6sAnxIeYtKNM1dK&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.rose&apos;, version(&apos;2.6.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.ide&apos;, version(&apos;4.2.0.I20120531-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.resources.ui&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.annotations.ui&apos;, version(&apos;1.1.300.v201002081900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.enterprise_ui.feature.feature.group&apos;, version(&apos;3.4.0.v201107072300-7b7JIM0FSK2WM1PS9Ar7AKUz0TrWn&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.doc.user.feature.jar&apos;, version(&apos;1.10.0.v201201161512-37D-7733L3D753L7BBF&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.postgresql.ui&apos;, version(&apos;1.0.0.v201107221506&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_adapters.feature.feature.jar&apos;, version(&apos;3.2.101.v20111212_1019-51F8OAkF79S8JCTA597K&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.feature.group&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jpa.eclipselink.feature.feature.jar&apos;, version(&apos;3.2.0.v201203150000-7M7J4F7RZHQYIwMsJyOWF5L&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.oda.designer.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-3368s7356485C59AB&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.view.feature.jar&apos;, version(&apos;2.3.0.201205300905-32-312316411A16&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.professional&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem.macosx&apos;, version(&apos;1.3.0.v20120522-1137&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.renderers.swt.cocoa&apos;, version(&apos;0.11.0.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.preview&apos;, version(&apos;1.1.101.v20111212_1019&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-7C7h90Et1axo7QmVkTdFIlGf6-6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.shells.ui&apos;, version(&apos;3.0.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jem.beaninfo.vm&apos;, version(&apos;2.0.300.v201004110600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.jobs&apos;, version(&apos;3.5.200.v20120521-2346&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-7F47WFC7sRdqScnobkd4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.axis.infopop&apos;, version(&apos;1.0.300.v200805140230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse&apos;, version(&apos;3.4.0.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ui&apos;, version(&apos;2.6.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsf.standard.tagsupport&apos;, version(&apos;1.2.100.v201104061711&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.ui&apos;, version(&apos;1.0.200.v20120530-1435&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.doc.user.contexts&apos;, version(&apos;1.7.0.20090521092446&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.msft.sqlserver&apos;, version(&apos;1.0.1.v201107221504&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.wsdl&apos;, version(&apos;1.2.300.v201109010430&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.screenshots&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.tabledataeditor&apos;, version(&apos;1.0.1.v201005250945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml_ui.feature.feature.jar&apos;, version(&apos;3.4.0.v201111021744-7H7GFeBDxumUpsl5liePhK3loz-m62J4rSz011R1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.runtime&apos;, version(&apos;0.8.0.v201108120515&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.generic.oc4j&apos;, version(&apos;1.5.206.v20090812&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.oda.xml&apos;, version(&apos;1.2.3.v201112061438&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;java_cup.runtime&apos;, version(&apos;0.10.0.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xmi&apos;, version(&apos;2.8.0.v20120530-0726&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.services.files.ftp&apos;, version(&apos;3.0.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jem.proxy&apos;, version(&apos;2.0.400.v201101101900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jaxb.eclipselink.core.schemagen&apos;, version(&apos;1.1.0.v201104120000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.xpath2.processor&apos;, version(&apos;2.1.1.v201204260055&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.professional.feature.group&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui.feature.jar&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.osgi.bundle.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.identity&apos;, version(&apos;3.1.200.v20120319-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsf.common.ui&apos;, version(&apos;1.2.100.v201104061711&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.trace&apos;, version(&apos;1.0.0.v20120523-2012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.connectorservice.local&apos;, version(&apos;2.1.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ui&apos;, version(&apos;2.6.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sap.maxdb.dbdefinition&apos;, version(&apos;1.0.0.v201107221507&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.core.refactoring&apos;, version(&apos;3.6.0.v20120523-1543&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sqlite&apos;, version(&apos;1.0.0.v201002041100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.web&apos;, version(&apos;1.1.600.v201203142300&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.feature.jar&apos;, version(&apos;2.8.0.v20120530-0726&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.oracle.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-548fAkF7AL7RBJANAI&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.db2.luw&apos;, version(&apos;1.0.2.v201107221502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.web_core.feature.feature.group&apos;, version(&apos;3.4.0.v201203141800-7E7HFSgAJz-mw9oH21HGMpHiKb_kVAz0D&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.team&apos;, version(&apos;0.9.1.v20120412-0100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d&apos;, version(&apos;3.8.0.201206011524&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sybase.asa.dbdefinition&apos;, version(&apos;1.0.0.v200906161800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.doc.user.contexts&apos;, version(&apos;1.7.0.20090521092446&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cvs_root&apos;, version(&apos;1.3.200.v20120525-1249-7B79FJJAkF7BF7RGE5FAJT&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingcocoa.macosx.x86_64org.eclipse.core.runtime&apos;, version(&apos;4.2.0.I20120531-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.java.tasks&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.feature.group&apos;, version(&apos;2.8.0.v20120530-0726&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.standard.schemas&apos;, version(&apos;1.0.500.v201111021744&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.wsil4j&apos;, version(&apos;1.0.0.v200901211807&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_adapters.feature.feature.group&apos;, version(&apos;3.2.101.v20111212_1019-51F8OAkF79S8JCTA597K&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ingres&apos;, version(&apos;1.0.0.v200906111150&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ui.feature.group&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.web.ui.infopop&apos;, version(&apos;1.0.300.v200805140415&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.doc.user&apos;, version(&apos;1.7.0.20090521092446&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws&apos;, version(&apos;1.1.300.v201204181727&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare&apos;, version(&apos;3.5.300.v20120522-1148&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xmleditor.doc.user&apos;, version(&apos;1.0.700.v201005192212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.ejb.annotation.model&apos;, version(&apos;1.1.300.v201003112036&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.core&apos;, version(&apos;3.7.100.v20120523-1257&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.mysql.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-5477AkF7AK7_AMENEA&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.servlet.ui.infopop&apos;, version(&apos;1.0.500.v201105122000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.files.ui&apos;, version(&apos;3.2.100.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.editor.feature.jar&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.io&apos;, version(&apos;8.1.3.v20120522&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.web&apos;, version(&apos;1.1.600.v201204190200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.db2.zseries.dbdefinition&apos;, version(&apos;1.0.4.v201107221502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.uddiregistry&apos;, version(&apos;1.0.500.v201004211805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.axis2.consumption.ui&apos;, version(&apos;1.0.103.v201004211805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingcocoa.macosx.x86_64org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;4.2.0.I20120531-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ui.feature.jar&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.launch&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.compiler.apt&apos;, version(&apos;1.0.500.v20120522-1651&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.feature.jar&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws.service.policy.ui&apos;, version(&apos;1.0.400.v201201111717&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.ide.feature.jar&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.annotations.core&apos;, version(&apos;1.1.300.v201004141630&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.routineeditor&apos;, version(&apos;1.0.0.v201107221520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.feature.jar&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.discovery.feature.group&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.doc.user.feature.group&apos;, version(&apos;1.10.0.v201201161512-37D-7733L3D753L7BBF&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sap.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-540AkF7AJ7YEJBU7S&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.ide.config.cocoa.macosx.x86_64&apos;, version(&apos;4.2.0.I20120531-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.pagedesigner.jsf.ui&apos;, version(&apos;1.2.100.v201104061711&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.wsdl.ui&apos;, version(&apos;1.2.500.v201108240518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsd.core&apos;, version(&apos;1.1.700.v201204102147&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws_core.feature.feature.jar&apos;, version(&apos;3.4.0.v201108230503-7L7RFoGFGtGd-xhuy-rRwz-2766&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsf.doc.user&apos;, version(&apos;1.2.1.v20100827&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui.feature.jar&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.axis.creation.ui&apos;, version(&apos;1.0.750.v201204120428&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide&apos;, version(&apos;3.8.0.v20120521-2329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sybase.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-7E46F9NiNc1QBgyT6T6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.shells.core&apos;, version(&apos;3.1.300.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext_feature.feature.jar&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.ui&apos;, version(&apos;1.0.200.v201202020230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer&apos;, version(&apos;5.0.0.v20120319-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.feature.jar&apos;, version(&apos;1.2.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.cxf.creation.core&apos;, version(&apos;1.0.200.v201205012246&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn_feature.feature.group&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change.edit&apos;, version(&apos;2.5.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jaxb.feature.feature.group&apos;, version(&apos;1.2.0.v201203150000-56A7AkF7BF7NAP7777&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd&apos;, version(&apos;2.8.0.v20120319-0555&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.directorywatcher&apos;, version(&apos;1.0.300.v20110808-1657&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jem.beaninfo&apos;, version(&apos;2.0.300.v200905030615&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.registry&apos;, version(&apos;1.1.200.v20120522-2049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sybase.asa.models&apos;, version(&apos;1.0.0.v201107221507&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.persistence.asm&apos;, version(&apos;3.3.1.v201206041142&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws.parser&apos;, version(&apos;1.0.403.v201004211805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change&apos;, version(&apos;2.8.0.v20120530-0726&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit&apos;, version(&apos;3.8.2.v3_8_2_v20100427-1100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit&apos;, version(&apos;4.10.0.v4_10_0_v20120426-0900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.webpageeditor.feature.feature.group&apos;, version(&apos;2.3.7.v201203021447-46DF9oB5896E6J7G7E3357&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro&apos;, version(&apos;3.4.200.v20120521-2344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.dstore.extra&apos;, version(&apos;2.1.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.hsqldb.ui&apos;, version(&apos;1.0.0.v201108120600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.webtools.doc.user&apos;, version(&apos;1.0.500.v201005192212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.core&apos;, version(&apos;3.6.100.v20120524-0627&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsdeditor.doc.user&apos;, version(&apos;1.0.800.v201005192212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.services&apos;, version(&apos;3.3.100.v20120522-1822&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.ui&apos;, version(&apos;1.1.600.v201205170400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;net.sourceforge.lpg.lpgjavaruntime&apos;, version(&apos;1.1.0.v201004271650&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-7C7h90Et1axo7QmVkTdFIlGf6-6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.infopop&apos;, version(&apos;1.0.300.v201004280700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wtp.web.capabilities&apos;, version(&apos;1.0.100.v201005102000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cvs.feature.group&apos;, version(&apos;1.3.200.v20120525-1249-7B79FJJAkF7BF7RGE5FAJT&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.web_ui.feature.feature.jar&apos;, version(&apos;3.4.0.v201203141800-7O7MFsGEMkBJz0rWbgfTLwn-4WKIocbP_pkka3Il&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.infopop&apos;, version(&apos;1.0.300.v200805140415&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;ch.qos.logback.slf4j&apos;, version(&apos;1.0.0.v20120123-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.services.dstore&apos;, version(&apos;3.2.0.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server_adapters.feature.feature.jar&apos;, version(&apos;3.2.200.v20120517_1442-20A77w31231628a2553&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.sqlbuilder.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-79-78EVVFNOGnTeK-SY&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.core&apos;, version(&apos;3.7.100.v20120521-2012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.manipulation&apos;, version(&apos;1.5.0.v20120523-1543&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.oracle.ui&apos;, version(&apos;1.0.3.v201201131121&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.bidi&apos;, version(&apos;0.9.0.v20120522-1841&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi&apos;, version(&apos;3.8.0.v20120529-1548&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.schemaobjecteditor.ui.pages&apos;, version(&apos;1.1.0.200810071&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.axis2tools.feature.feature.jar&apos;, version(&apos;1.1.200.v201103022333-78-FF0DZRDKDDePSKwHj&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.pagedesigner.jsp.core&apos;, version(&apos;1.2.100.v201112111111&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.doc.user.feature.jar&apos;, version(&apos;1.10.0.v201201161512-37D-7733L3D753L7BBF&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.hsqldb.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-67E0AqGBM7KfNTHwKO9ILX&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.xml&apos;, version(&apos;1.3.4.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jpa.core&apos;, version(&apos;3.2.0.v201205290000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.feature.group&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.services&apos;, version(&apos;1.0.0.v20120521-2346&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.apparat&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws&apos;, version(&apos;1.0.600.v201108242234&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.sql&apos;, version(&apos;1.0.1.v201110050515&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.manipulation&apos;, version(&apos;1.0.400.v201204261600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jpa.eclipselink.ui&apos;, version(&apos;2.2.0.v201205020001&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server_ui.feature.feature.group&apos;, version(&apos;3.4.0.v20120503_1042-7A77FHr9xFcC2CFLZBCJMHLg7D64&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jpa.feature.feature.jar&apos;, version(&apos;3.2.0.v201203150000-7S7K8aFBBoPaoQM_ZRKUVF5L&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jaxb.eclipselink.branding&apos;, version(&apos;1.2.0.v201203150000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.user.ui.feature.group&apos;, version(&apos;2.2.0.v20120524-0542-62DG9JXTlShQUbcP-bhrkOUjZ_P7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxb.core&apos;, version(&apos;1.0.100.v201104031139&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.terminals.ui&apos;, version(&apos;1.2.0.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jee.ui&apos;, version(&apos;1.0.500.v201205170400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator.manipulator&apos;, version(&apos;2.0.0.v20110808-1657&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.ecore&apos;, version(&apos;2.6.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.data.ui&apos;, version(&apos;1.2.1.v201010270945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.continuation&apos;, version(&apos;8.1.3.v20120522&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.common.feature.feature.jar&apos;, version(&apos;1.2.0.v201203150000-66-AkF7BF7PBN7778&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.jarprocessor&apos;, version(&apos;1.0.200.v20110808-1657&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws_wsdl15.feature.feature.jar&apos;, version(&apos;1.5.301.v201102200555-2407w312123151655&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.hsqldb&apos;, version(&apos;1.0.0.v201107221502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extras.feature.feature.group&apos;, version(&apos;1.1.0.v20120524-0542-7A6FEcDiVOTg-s_HuZrEtBYz-Cdi&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl.jaxp.debug&apos;, version(&apos;1.0.200.v201103081922&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.consumption.ui.doc.user&apos;, version(&apos;1.0.600.v201005192217&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.apache.derby.dbdefinition&apos;, version(&apos;1.0.2.v201107221459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.useractions.feature.jar&apos;, version(&apos;1.1.400.201205300905-31FBV773573D933L3D&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jdom&apos;, version(&apos;1.0.0.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jdom&apos;, version(&apos;1.1.1.v201101151400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.doc.user&apos;, version(&apos;3.4.0.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.product&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.feature.feature.jar&apos;, version(&apos;1.4.0.v201111090639-7H7DFeHFC7sRemSZgYbe4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.launching.macosx&apos;, version(&apos;3.2.100.v20120523-1953&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.flatfile.ui&apos;, version(&apos;3.1.3.v201203221637&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.jee.feature.feature.jar&apos;, version(&apos;1.5.0.20120602-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.jdt.classpath&apos;, version(&apos;1.0.1.v201107221501&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.ui.feature.jar&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.debug.ui&apos;, version(&apos;1.0.200.v201203071952&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.web_ui.feature.feature.group&apos;, version(&apos;3.4.0.v201203141800-7O7MFsGEMkBJz0rWbgfTLwn-4WKIocbP_pkka3Il&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.db.derby.ui&apos;, version(&apos;1.0.0.v200906020900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.servlet.jsp&apos;, version(&apos;2.2.0.v201112011158&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.preview.adapter&apos;, version(&apos;1.1.100.v20120517_1638&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.web.core&apos;, version(&apos;1.0.500.v201205241808&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.axis2.core&apos;, version(&apos;1.0.204.v201004211805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ui.feature.jar&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.fproj.enablement.jdt.feature.jar&apos;, version(&apos;3.4.0.v201108231500-377DG8s73543J5H6D66&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery.compatibility&apos;, version(&apos;1.0.101.v20120524-1717&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.parsers.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-623BgJ9EE9ZJRDZLA&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxws.feature.feature.group&apos;, version(&apos;1.2.0.v201204151854-7E7AF70F8NcJS_KqT5TpXq&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.logging&apos;, version(&apos;1.0.4.v201101211617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.msft.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-544AkF7AL7MDMAQ8O&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.doc.user&apos;, version(&apos;1.4.2.v201205290002&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jem&apos;, version(&apos;2.0.600.v201201051400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.terminals.ssh&apos;, version(&apos;1.0.200.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.services&apos;, version(&apos;0.10.1.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.designer.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-4127w312312232267&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit.feature.jar&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.editor&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.haxe.core&apos;, version(&apos;1.0.0.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.annotations.controller&apos;, version(&apos;1.1.300.v200908252030&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui.feature.group&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.webservice.ui&apos;, version(&apos;1.1.500.v201105122000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.sse.ui&apos;, version(&apos;1.3.100.v201204260100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.core&apos;, version(&apos;1.0.200.v20120530-1435&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-7N8B7CFDsn4hwBXz-0AGu4j6V85I&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.bugs&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.help.ui&apos;, version(&apos;1.1.1.I20110907-0947&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.validation&apos;, version(&apos;1.2.400.v201204260100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.ide.feature.group&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.ssh.feature.group&apos;, version(&apos;3.0.400.201205300905-7A4FEc7F7BF7RJ77g7R&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws.explorer&apos;, version(&apos;1.0.700.v201203072334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.lib.jdom&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.cvs.ui&apos;, version(&apos;3.3.500.v20120522-1148&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.reconciler.dropins&apos;, version(&apos;1.1.200.v20120301-2145&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.dbws.eclipselink.feature.feature.jar&apos;, version(&apos;1.1.100.v201203150000-797EBiCcNBHKCZEYAwHIF5L&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.telnet.feature.group&apos;, version(&apos;2.3.0.201205300905-775FD3879AE8MH9BZFP4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.generic.core&apos;, version(&apos;1.0.700.v20101219&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.tracwiki.ui&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.web.support.jsp&apos;, version(&apos;1.0.500.v201204260100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.core&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxws.dom.runtime&apos;, version(&apos;1.0.200.v201109042201&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.oda.ws&apos;, version(&apos;1.2.4.v201203221631&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit4&apos;, version(&apos;4.8.1.v20120523-1257&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.log&apos;, version(&apos;1.0.300.v20120530-1435&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.terminals.core&apos;, version(&apos;1.0.300.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.dbws.eclipselink.core.gen&apos;, version(&apos;1.0.0.v201104110000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.index.ui&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.ds&apos;, version(&apos;1.4.0.v20120522-1841&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.base&apos;, version(&apos;3.6.100.v201205311500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server_core.feature.feature.group&apos;, version(&apos;3.4.0.v20120503_1042-31FEe8s73554A4Fa2153&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.repositories&apos;, version(&apos;0.9.1.v20120412-0100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.db2.luw.ui&apos;, version(&apos;1.0.3.v201202100836&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt&apos;, version(&apos;3.8.0.v201205311500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.util&apos;, version(&apos;3.2.300.v20120522-1822&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.feature.group&apos;, version(&apos;2.8.0.v20120530-0726&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.plan&apos;, version(&apos;1.0.0.v201107221520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sybase&apos;, version(&apos;1.0.1.v201107221507&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit4.runtime&apos;, version(&apos;1.1.200.v20120523-1257&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.artifact.repository&apos;, version(&apos;1.1.200.v20120430-1959&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.feature.group&apos;, version(&apos;3.8.0.v20120525-1249-7c7vFitFFt6Zr5_yF0M3KRI&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.modelbase.dbdefinition&apos;, version(&apos;1.0.2.v201107221519&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.postgresql.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-553AkF7AK8PCRBQBP&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.enterprise&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.dbws.eclipselink.branding&apos;, version(&apos;1.1.100.v201203150000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.profile&apos;, version(&apos;3.2.7.v201203291105&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.jee&apos;, version(&apos;1.5.0.20120131-1544&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsf.apache.trinidad.tagsupport&apos;, version(&apos;1.1.200.v201104061711&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.jdt.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-2-07w312218332612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.xpath2&apos;, version(&apos;1.1.0.v200910101444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator.resources&apos;, version(&apos;3.4.400.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.enterprise_core.feature.feature.group&apos;, version(&apos;3.4.0.v201108110300-52FShAkF7BA8O8J9OC8&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2ecore&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.ui&apos;, version(&apos;1.1.202.v20110419&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.core&apos;, version(&apos;1.1.400.v20120522-1148&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.project.facet.core&apos;, version(&apos;1.4.201.v201108161900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.swt&apos;, version(&apos;0.10.1.v20120525-2014&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.feature.jar&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.net&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.jasper.glassfish&apos;, version(&apos;2.2.2.v201205150955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.db.generic.ui&apos;, version(&apos;1.0.1.v201107221459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.webpageeditor.feature.feature.jar&apos;, version(&apos;2.3.7.v201203021447-46DF9oB5896E6J7G7E3357&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.schemaobjecteditor.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-4208375LG5BJ93413&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.core&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.services&apos;, version(&apos;3.2.200.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.monitor.core&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sybase.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-7E46F9NiNc1QBgyT6T6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.ejb&apos;, version(&apos;1.1.600.v201205030130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.compiler.adapter&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.annotations.core&apos;, version(&apos;1.2.0.v201203272107&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.bindings&apos;, version(&apos;0.10.1.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ingres.dbdefinition&apos;, version(&apos;1.0.0.v200906161800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsf.apache.trinidad.tagsupport.feature.feature.jar&apos;, version(&apos;2.2.200.v201105111126-20A77w312215172822&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml_core.feature.feature.group&apos;, version(&apos;3.4.0.v201111021744-7C7OFm4F7RZHQRIpOz-P2Xk&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.intro&apos;, version(&apos;1.7.0.v201005281800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jee.ejb&apos;, version(&apos;1.0.301.v201007070821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsf.facelet.core&apos;, version(&apos;1.0.200.v201205161442&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.frameworks&apos;, version(&apos;1.1.600.v201204190200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sybase.ase.dbdefinition&apos;, version(&apos;1.0.0.v201107221507&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.importexport&apos;, version(&apos;1.2.300.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.mail&apos;, version(&apos;1.4.0.v201005080615&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.ssl&apos;, version(&apos;1.0.0.v20120319-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.services.telnet&apos;, version(&apos;2.0.300.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.modelbase.derby&apos;, version(&apos;1.0.0.v201107221519&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata&apos;, version(&apos;2.1.0.v20120430-2001&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jpa.eclipselink.core.ddlgen&apos;, version(&apos;2.1.0.v201203150000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.net&apos;, version(&apos;2.2.0.v201101241833&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.org.eclipse.update.feature.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jpa.db&apos;, version(&apos;2.1.100.v201203150000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.terminals.feature.jar&apos;, version(&apos;1.2.0.201205300905-773Eo7H89G8OJ8Db8NB27&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.project.facet.core&apos;, version(&apos;1.4.300.v201111030424&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.launching&apos;, version(&apos;3.6.100.v20120523-1453&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.xpath2.processor.feature.feature.jar&apos;, version(&apos;2.0.100.v201203131922-7A7K0CcNBGPCTJ_FUOb&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jee&apos;, version(&apos;1.0.500.v201202020745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.parsers.sql&apos;, version(&apos;1.0.2.v201107221520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingepp.package.jee.configuration&apos;, version(&apos;1.5.0.20120602-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.ui&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.common.eclipselink.branding&apos;, version(&apos;1.2.0.v201203150000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.identity.feature.group&apos;, version(&apos;1.0.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxws.doc.user&apos;, version(&apos;1.0.200.v201205231938&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.runtime&apos;, version(&apos;3.4.300.v20120523-1453&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.doc.user&apos;, version(&apos;1.1.400.v201008122303&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.formatter&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.standard.schemas&apos;, version(&apos;1.2.0.v201101142102&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.jmx&apos;, version(&apos;8.1.4.v20120524&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.project.facet.ui&apos;, version(&apos;1.4.200.v201008182133&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.feature.group&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.jetty&apos;, version(&apos;3.0.0.v20120522-1841&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.xml.bind&apos;, version(&apos;2.1.9.v201005080401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher.eclipse&apos;, version(&apos;1.1.0.v20120511-1931&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.slf4j.api&apos;, version(&apos;1.6.4.v20120130-2120&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.feature.group&apos;, version(&apos;1.4.0.v20120528-1714-8P7vFOTFK_Qj4JmCLJXM8Tn&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.exporter&apos;, version(&apos;2.6.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.bugzilla.ide&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench.texteditor&apos;, version(&apos;3.8.0.v20120523-1310&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.console.profile&apos;, version(&apos;1.0.10.v201109250955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.data.core&apos;, version(&apos;1.2.1.v201110050500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ingres.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-540AkF78Z7UCRAQDB&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws.ui&apos;, version(&apos;1.1.200.v201004211805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.axis2tools.feature.feature.group&apos;, version(&apos;1.1.200.v201103022333-78-FF0DZRDKDDePSKwHj&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsf.ui&apos;, version(&apos;1.3.200.v201202131530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.feature.group&apos;, version(&apos;4.2.0.v20120528-1648-7IAPA7BrHQicRoQXOz0Obz-blRCA&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.doc.flash&apos;, version(&apos;3.2.0.1002&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.feature.jar&apos;, version(&apos;3.2.0.201205300905-41-312316411A16&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.core&apos;, version(&apos;3.2.400.v20120523-1752&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.feature.group&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.bugzilla.ui&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingcocoa.macosx.x86_64org.eclipse.update.configurator&apos;, version(&apos;4.2.0.I20120531-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jpa.eclipselink.branding&apos;, version(&apos;3.2.0.v201203150000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.ws.commons.util&apos;, version(&apos;1.0.1.v20100518-1140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.el&apos;, version(&apos;2.2.0.v201108011116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.core&apos;, version(&apos;3.8.0.v20120523-2052&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.extension.feature.jar&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-7F47WFC7sRdqScnobkd4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.apache.derby.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-77798fBmKDQ2MoTTLwdv9ILX&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ingres.ui&apos;, version(&apos;1.0.0.v201105270214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.edit&apos;, version(&apos;1.2.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.cocoa.macosx.x86_64&apos;, version(&apos;3.100.0.v4232d&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.modelbase.sql&apos;, version(&apos;1.0.5.v201110151330&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.apparat&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.runtime&apos;, version(&apos;3.8.0.v20120521-2346&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.professional.feature.jar&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.mediawiki.core&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.collections&apos;, version(&apos;3.2.0.v201005080500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.ui&apos;, version(&apos;3.8.0.v20120524-1551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.modelbase.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-7707CCcNBHIEQJXHUNf&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl.debug.ui&apos;, version(&apos;1.0.200.v201101281837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.intro.feature.group&apos;, version(&apos;1.10.0.v201201161512-26-7w312116392911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.forms&apos;, version(&apos;3.5.200.v20120521-2329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.textile.core&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server_userdoc.feature.feature.jar&apos;, version(&apos;3.3.100.v20110303-2-Eo7w3121162A3329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws_ui.feature.feature.jar&apos;, version(&apos;3.4.0.v201203150412-7I7CFkWEtEoXHw284K6n3-oEz-uotfK5qz-68n73&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sybase.ase.ui&apos;, version(&apos;1.0.1.v200906020900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.feature.feature.group&apos;, version(&apos;1.4.0.v201111090639-7H7DFeHFC7sRemSZgYbe4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common_core.feature.feature.jar&apos;, version(&apos;3.4.0.v201107190500-7B7EFMSF7RZHOjIpQz-P-QS&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.informix.dbdefinition&apos;, version(&apos;1.0.4.v201107221502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.parsers.sql.lexer&apos;, version(&apos;1.0.1.v201107221520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.consumption.ui&apos;, version(&apos;1.1.500.v201204102147&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.refactoring&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.launch&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.variables&apos;, version(&apos;3.2.600.v20120521-2012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.db.generic&apos;, version(&apos;1.0.0.v201107221520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.util&apos;, version(&apos;8.1.3.v20120522&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.core&apos;, version(&apos;3.3.0.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.eclipse&apos;, version(&apos;2.1.100.v20120428-0117&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.core&apos;, version(&apos;1.0.200.v20120530-1435&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingcocoa.macosx.x86_64org.eclipse.equinox.common&apos;, version(&apos;4.2.0.I20120531-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.core&apos;, version(&apos;1.1.700.v201204241737&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.discovery&apos;, version(&apos;0.2.0.v201004190315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.msft.sqlserver.dbdefinition&apos;, version(&apos;1.0.1.v201201240505&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.sse.ui.infopop&apos;, version(&apos;1.0.300.v201004150328&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.debug.rhino.debugger&apos;, version(&apos;1.0.300.v201109150503&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director.app&apos;, version(&apos;1.0.300.v20120428-0517&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.doc.user.feature.group&apos;, version(&apos;1.10.0.v201201161512-47C08w95FFAK89FHEC7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.axis2.consumption.core&apos;, version(&apos;1.0.105.v201004211805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxws.dom.feature.feature.group&apos;, version(&apos;1.0.200.v201109042201-5-F8NAkF7BB7U8PEK8K&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.debug.ui&apos;, version(&apos;3.6.100.v20120530-1425&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl&apos;, version(&apos;1.2.0.v201009121641&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.persistence.moxy&apos;, version(&apos;2.4.0.v20120604-r11619&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.postgresql.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-553AkF7AK8PCRBQBP&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.sqm.server.ui&apos;, version(&apos;1.1.100.v201202021103&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.editor.feature.group&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.feature.group&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.axis2.ui&apos;, version(&apos;1.0.303.v201003110431&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.context.core&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xalan&apos;, version(&apos;2.7.1.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.engine&apos;, version(&apos;2.2.0.v20120501-1502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.debug.transport&apos;, version(&apos;1.0.100.v201109150330&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.java_feature.feature.group&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.postgresql.dbdefinition&apos;, version(&apos;1.0.2.v201110070445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.enterprise_userdoc.feature.feature.group&apos;, version(&apos;3.3.100.v201105122000-62FUGBgJ9EA9aEeHRHc&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxrs.core&apos;, version(&apos;1.0.400.v201202152223&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.importexport&apos;, version(&apos;1.0.1.v20110818-1344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.help.ui&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxws.dom.feature.feature.jar&apos;, version(&apos;1.0.200.v201109042201-5-F8NAkF7BB7U8PEK8K&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.feature.jar&apos;, version(&apos;1.4.0.v20120528-1714-8P7vFOTFK_Qj4JmCLJXM8Tn&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.jee.feature.feature.group&apos;, version(&apos;1.5.0.20120602-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.repositories.core&apos;, version(&apos;1.0.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.junit.runtime&apos;, version(&apos;3.4.200.v20120530-1435&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.launching&apos;, version(&apos;3.6.100.v20120523-1953&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl.launching&apos;, version(&apos;1.0.200.v201103081922&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.common.utility&apos;, version(&apos;2.1.0.v201205020001&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.xpath2.wtptypes&apos;, version(&apos;2.0.0.v201103212215&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.creation.ui&apos;, version(&apos;1.0.700.v201205041550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.configuration_root.cocoa.macosx.x86_64&apos;, version(&apos;1.0.0.I20120531-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.mediawiki.ui&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.jdt.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-2-07w312218332612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.internet.monitor.ui&apos;, version(&apos;1.0.606.v20120306_1603&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.tracwiki.core&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.properties.tabbed&apos;, version(&apos;3.5.300.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jaxb.ui&apos;, version(&apos;1.3.0.v201205180000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server_userdoc.feature.feature.group&apos;, version(&apos;3.3.100.v20110303-2-Eo7w3121162A3329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.runtime.compatibility&apos;, version(&apos;3.2.200.v20120521-2346&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.ui&apos;, version(&apos;3.5.300.v20120523-1752&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.repositories.ui&apos;, version(&apos;1.0.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient.ssl&apos;, version(&apos;1.0.0.v20120319-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.parsers.sql.query&apos;, version(&apos;1.2.1.v201201250511&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.xmlrpc&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl.exslt.ui&apos;, version(&apos;1.0.0.v201006012005&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.environment&apos;, version(&apos;1.0.400.v200912181832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal&apos;, version(&apos;3.2.0.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2xml&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.debugger.core&apos;, version(&apos;1.0.1.v201107221520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.cxf.feature.feature.group&apos;, version(&apos;1.1.0.v201201312103-7H79FHxFAKlbotH5e9l3vAA6MBG&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsf.feature.feature.jar&apos;, version(&apos;3.4.0.v201111022140-7E7JFBZF9JgLWZLz0U0QoZm3357&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-7N8B7CFDsn4hwBXz-0AGu4j6V85I&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.feature.group&apos;, version(&apos;3.4.0.201205300905-7L7IFBV83omxZWwIDyHWipb2Sz-f&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.team.ui&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.refactoring&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.el&apos;, version(&apos;2.2.0.v201108011116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;config.a.jre.javase&apos;, version(&apos;1.6.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery&apos;, version(&apos;1.0.200.v20120524-1717&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.console&apos;, version(&apos;1.0.300.v20120429-0125&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatechecker&apos;, version(&apos;1.1.200.v20110808-1657&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.web_ui.feature.feature.group&apos;, version(&apos;3.4.0.v201111022313-7F7DFSgC25TrkWsplelWwGPu4Ajn5UiEiyuqxZp4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.edit&apos;, version(&apos;2.6.0.v20120319-0555&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.feed&apos;, version(&apos;1.0.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.context.tasks.ui&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench&apos;, version(&apos;0.10.2.v20120531-1742&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.core&apos;, version(&apos;3.5.200.v20120522-1148&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.core&apos;, version(&apos;3.3.500.v20120522-1651&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws_wsdl15.feature.feature.group&apos;, version(&apos;1.5.301.v201102200555-2407w312123151655&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.activation&apos;, version(&apos;1.1.0.v201108011116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui.templates&apos;, version(&apos;3.4.500.v20120523-2012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws_core.feature.feature.group&apos;, version(&apos;3.4.0.v201108230503-7L7RFoGFGtGd-xhuy-rRwz-2766&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.transport.ecf&apos;, version(&apos;1.0.100.v20120305-0333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.identity&apos;, version(&apos;0.9.1.v20120412-0100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp_root&apos;, version(&apos;4.2.0.v20120528-1648-7IAPA7BrHQicRoQXOz0Obz-blRCA&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.cheatsheets&apos;, version(&apos;3.4.200.v20120521-2344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxws.feature.feature.jar&apos;, version(&apos;1.2.0.v201204151854-7E7AF70F8NcJS_KqT5TpXq&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.ibm.icu&apos;, version(&apos;4.4.2.v20110823&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ejb.ui.infopop&apos;, version(&apos;1.0.300.v2010022311013&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.dtdeditor.doc.user&apos;, version(&apos;1.0.700.v201008112018&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.net&apos;, version(&apos;1.2.100.v20120522-1148&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.app&apos;, version(&apos;1.3.100.v20120522-1841&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.msft.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-544AkF7AL7MDMAQ8O&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.renderers.swt&apos;, version(&apos;0.10.1.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.css&apos;, version(&apos;1.6.0.v201011041432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.css.sac&apos;, version(&apos;1.3.1.v200903091627&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.doc&apos;, version(&apos;1.4.0.v201202031526&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wtp.jee.capabilities&apos;, version(&apos;1.0.100.v201005102000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.oracle.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-548fAkF7AL7RBJANAI&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.commands&apos;, version(&apos;3.6.1.v20120521-2329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.enterprise_userdoc.feature.feature.jar&apos;, version(&apos;3.3.100.v201105122000-62FUGBgJ9EA9aEeHRHc&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.local.feature.jar&apos;, version(&apos;2.1.400.201205300905-7B4FSg7J9EJ9YO99r9Y&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore&apos;, version(&apos;2.8.0.v20120530-0726&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.ui&apos;, version(&apos;3.5.200.v20120521-2344&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server_core.feature.feature.jar&apos;, version(&apos;3.4.0.v20120503_1042-31FEe8s73554A4Fa2153&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.processes.shell.linux&apos;, version(&apos;1.1.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xmlrpc&apos;, version(&apos;3.0.0.v20100427-1100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.context_feature.feature.jar&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.db2.iseries&apos;, version(&apos;1.0.2.v201107221502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.design.ui&apos;, version(&apos;3.2.7.v201205221153&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.html.ui.infopop&apos;, version(&apos;1.0.200.v201004150328&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications&apos;, version(&apos;0.9.1.v20120412-0100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.asdoc&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.tomcat.ui&apos;, version(&apos;1.1.300.v20120420_1012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.context.ui&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;ch.qos.logback.classic&apos;, version(&apos;1.0.0.v20111214-2030&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ui.feature.group&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.discovery.ui&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt_root&apos;, version(&apos;3.8.0.v20120525-1249-8-8nFqlFNOfwKDRF3dXMdHyBC834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.db.generic.ui&apos;, version(&apos;1.0.0.v200906020900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.processes.local&apos;, version(&apos;2.1.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.dstore.security&apos;, version(&apos;3.0.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.enterprise_ui.feature.feature.jar&apos;, version(&apos;3.4.0.v201107072300-7b7JIM0FSK2WM1PS9Ar7AKUz0TrWn&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.validation.infopop&apos;, version(&apos;1.0.300.v200806041506&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.annotation&apos;, version(&apos;1.0.0.v20101115-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filebuffers&apos;, version(&apos;3.5.200.v20120523-1310&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.axis&apos;, version(&apos;1.4.0.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.postgresql&apos;, version(&apos;1.1.1.v201205252207&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.ui&apos;, version(&apos;1.1.400.v20120522-1148&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.terminals.feature.group&apos;, version(&apos;1.2.0.201205300905-773Eo7H89G8OJ8Db8NB27&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.xpath.ui&apos;, version(&apos;1.1.101.v201204260040&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.feature.group&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jpa.eclipselink.core&apos;, version(&apos;2.2.0.v201205240000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.files.core&apos;, version(&apos;3.3.0.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.local.feature.group&apos;, version(&apos;2.1.400.201205300905-7B4FSg7J9EJ9YO99r9Y&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsf.facesconfig&apos;, version(&apos;1.2.100.v2012030703072246&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.designer.core.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-7B7C7LCcNBGTBfLREXcc&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.repositories.feature.group&apos;, version(&apos;1.0.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding&apos;, version(&apos;1.2.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.web.ui&apos;, version(&apos;1.1.600.v201109220400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.design&apos;, version(&apos;3.3.5.v201204241156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-7H7C7QCcNBHKDYJgFYLT&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.console&apos;, version(&apos;3.5.100.v20120521-2012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt&apos;, version(&apos;3.100.0.v4232d&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.sqm.core&apos;, version(&apos;1.2.5.v201205240353&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsf.core&apos;, version(&apos;1.4.0.v201205241050&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jaxb.feature.feature.jar&apos;, version(&apos;1.2.0.v201203150000-56A7AkF7BF7NAP7777&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sybase.asa.ui&apos;, version(&apos;1.0.1.v200906111204&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingepp.package.jee.ini.cocoa.macosx.x86_64&apos;, version(&apos;1.5.0.20120602-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.hamcrest.core&apos;, version(&apos;1.1.0.v20090501071000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.monitor.feature.jar&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.validation.ui&apos;, version(&apos;1.2.400.v201204260100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.modelbase.sql.query&apos;, version(&apos;1.1.2.v201110151315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.mxml&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sap.maxdb&apos;, version(&apos;1.0.0.v201107221507&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.wsi.ui&apos;, version(&apos;1.0.502.v201104071820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.ui.infopop&apos;, version(&apos;1.1.100.v201005192130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.connectorservice.dstore&apos;, version(&apos;3.1.300.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.doc.user&apos;, version(&apos;1.0.600.v201005192217&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.core&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.oda.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-7A7T7CDZRDKHF_HnGjOX&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding&apos;, version(&apos;1.4.1.v20120521-2329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.ui&apos;, version(&apos;1.1.500.v200911190730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.concurrent&apos;, version(&apos;1.0.300.v20120522-2049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.ui&apos;, version(&apos;1.0.200.v20120523-1453&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.servlet&apos;, version(&apos;1.1.300.v20120522-1841&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.ssh.feature.jar&apos;, version(&apos;3.0.400.201205300905-7A4FEc7F7BF7RJ77g7R&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.data.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-644BgJ9ECCLFTAfMO&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui.feature.group&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ql&apos;, version(&apos;2.0.100.v20110808-1657&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server_adapters.ext.feature.feature.jar&apos;, version(&apos;3.3.100.v20110810_1722-777HFL5CcNBDmBfJVFHJD6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.core&apos;, version(&apos;1.0.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface&apos;, version(&apos;3.8.0.v20120521-2329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.connectorservice.telnet&apos;, version(&apos;1.2.300.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.db2.luw.dbdefinition&apos;, version(&apos;1.0.4.v201107221502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.http.core&apos;, version(&apos;1.0.200.v20090429&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common_ui.feature.feature.group&apos;, version(&apos;3.4.0.v201203141800-7C7AFeBEdhOawe9e8mNfykJqRz00Q0RT&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform_root&apos;, version(&apos;4.2.0.v20120528-1648-9JF7BHV8FyMteji0MoOeOuU6sAnxIeYtKNM1dK&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda&apos;, version(&apos;3.3.3.v201110130935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jaxb.eclipselink.ui&apos;, version(&apos;1.3.0.v201204160000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.browser&apos;, version(&apos;3.4.0.v20120521-2329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui&apos;, version(&apos;3.103.0.v20120521-2329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.team_feature.feature.jar&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.msft.sqlserver.ui&apos;, version(&apos;1.0.2.v201201131118&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.doc.user&apos;, version(&apos;1.7.0.20090521092446&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.formatter&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.contexts&apos;, version(&apos;1.1.0.v20120523-2004&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.parsers.sql.xml.query&apos;, version(&apos;1.0.0.v201107221520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jaxb.core.schemagen&apos;, version(&apos;1.0.200.v201203050000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.search&apos;, version(&apos;3.8.0.v20120523-1540&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.hsqldb.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-67E0AqGBM7KfNTHwKO9ILX&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.servlet.ui&apos;, version(&apos;1.1.600.v201202011057&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt.theme&apos;, version(&apos;0.9.2.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.debug&apos;, version(&apos;3.7.100.v20120529-1702&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.ui.dse&apos;, version(&apos;1.1.4.v201107221459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn_feature.feature.jar&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.designer.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-4127w312312232267&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.results.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-57B78AkF7BD7PGE9_DH&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.editor&apos;, version(&apos;2.6.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.modelbase.sql.query.edit&apos;, version(&apos;1.0.1.v201110151245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml_core.feature.feature.jar&apos;, version(&apos;3.4.0.v201111021744-7C7OFm4F7RZHQRIpOz-P2Xk&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.di&apos;, version(&apos;0.10.1.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;epp.package.jee.executable.cocoa.macosx.x86_64.Eclipse&apos;, version(&apos;1.5.0.20120602-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.swf&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.contenttype&apos;, version(&apos;3.4.200.v20120523-2004&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ant&apos;, version(&apos;2.7.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.swc&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.feature.jar&apos;, version(&apos;4.2.0.v20120528-1648-9JF7BHV8FyMteji0MoOeOuU6sAnxIeYtKNM1dK&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.common.ui&apos;, version(&apos;1.0.0.v201107221520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher.cocoa.macosx.x86_64&apos;, version(&apos;1.1.200.v20120522-1813&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.feature.jar&apos;, version(&apos;1.0.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.dtd.ui.infopop&apos;, version(&apos;1.0.400.v201008112018&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.resources&apos;, version(&apos;3.8.0.v20120522-2034&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk&apos;, version(&apos;1.0.200.v20120515-1650&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.externaltools&apos;, version(&apos;3.2.100.v20120530-1753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di&apos;, version(&apos;1.1.0.v20120521-2346&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.jaxws_userdoc.feature.feature.group&apos;, version(&apos;1.0.200.v201205012246-3-DF8s73573D795LAF&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl.exslt.core&apos;, version(&apos;1.0.0.v201005240426&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cvs&apos;, version(&apos;1.2.0.v201205311500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.feature.group&apos;, version(&apos;1.2.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository&apos;, version(&apos;2.2.0.v20120524-1945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui&apos;, version(&apos;3.7.0.v20120530-1420&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.persistence.jpa.jpql.source&apos;, version(&apos;2.0.0.v20120604-r11619&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.fontLibraryCreator&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.observable&apos;, version(&apos;1.4.1.v20120521-2329&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.ddl.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-279-78B089G8S_IRTJrXkO2_s&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher.cocoa.macosx.x86_64&apos;, version(&apos;1.1.200.v20120522-1813&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.ui&apos;, version(&apos;1.0.0.v201107221502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.editors&apos;, version(&apos;3.8.0.v20120523-1540&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.doc.user&apos;, version(&apos;3.8.0.v20120531-1353&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.feature.jar&apos;, version(&apos;3.8.0.v20120525-1249-8-8nFqlFNOfwKDRF3dXMdHyBC834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jpa.branding&apos;, version(&apos;3.2.0.v201203150000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.ui&apos;, version(&apos;3.3.300.v20120522-1651&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jaxb.eclipselink.feature.feature.jar&apos;, version(&apos;1.3.0.v201203150000-777B-BgJ9EI9UDW8z0AA72A&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.ui&apos;, version(&apos;1.1.100.v20120522-2049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.command.env.core&apos;, version(&apos;1.0.205.v201004211805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.db.derby&apos;, version(&apos;1.0.0.v201107221520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.professional&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.feature.group&apos;, version(&apos;1.1.0.v20120524-0542-8297Fm3FWmE7h3AXyBchSbZ&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.update.configurator&apos;, version(&apos;3.3.200.v20120523-1752&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.xml.soap&apos;, version(&apos;1.2.0.v201005080501&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.project.facet.ui&apos;, version(&apos;1.4.300.v201111030424&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jaxb.eclipselink.feature.feature.group&apos;, version(&apos;1.3.0.v201203150000-777B-BgJ9EI9UDW8z0AA72A&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analysis&apos;, version(&apos;2.9.1.v201101211721&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.swfViewer&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.feature.group&apos;, version(&apos;1.0.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.web_userdoc.feature.feature.group&apos;, version(&apos;3.3.0.v201102200555-31Eo8s734B3E4H7799&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext_feature.feature.group&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.log4j&apos;, version(&apos;1.2.15.v201012070815&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene&apos;, version(&apos;1.9.1.v201101211617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene&apos;, version(&apos;2.9.1.v201101211721&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.team.cvs&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wtp.javascript.capabilities&apos;, version(&apos;1.0.100.v201005102000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.oracle&apos;, version(&apos;1.0.0.v201107221506&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.welcome&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui&apos;, version(&apos;2.2.0.v20120524-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.doc.user.feature.jar&apos;, version(&apos;1.10.0.v201201161512-47C08w95FFAK89FHEC7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.identity.feature.jar&apos;, version(&apos;1.0.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.annotation&apos;, version(&apos;1.0.0.v20120522-1651&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.infopop&apos;, version(&apos;1.0.300.v200805140230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.core.feature.jar&apos;, version(&apos;3.4.0.201205300905-7a7NFm-7sResSX4RTNSW&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;epp.package.jee.executable.cocoa.macosx.x86_64&apos;, version(&apos;1.5.0.20120602-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqldevtools.ddlgen.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-7A-78F7RZHQSIqWjN1Zr&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.mysql.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-5477AkF7AK7_AMENEA&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.bcel&apos;, version(&apos;5.2.0.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.axis2.ui.doc.user&apos;, version(&apos;1.0.100.v201005192217&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.persistence.jpa&apos;, version(&apos;2.4.0.v20120604-r11619&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.shell&apos;, version(&apos;0.8.0.v201110170705&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jpa.gen&apos;, version(&apos;2.2.0.v201205020001&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.discovery&apos;, version(&apos;1.0.0.v20110808-1657&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.connectorservice.ssh&apos;, version(&apos;2.1.300.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.runtime.compatibility.registry&apos;, version(&apos;3.5.100.v20120521-2346&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.ui&apos;, version(&apos;1.0.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.java.ui&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.emf&apos;, version(&apos;1.2.100.v201101101900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.inject&apos;, version(&apos;1.0.0.v20091030&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.ui.refactoring&apos;, version(&apos;3.7.0.v20120523-1543&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl.feature.feature.jar&apos;, version(&apos;1.3.100.v201111021744-7T7ZFUaFIqUoJuvaKoCpQDKaGVPc&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.pagedesigner&apos;, version(&apos;1.3.200.v2012030703072246&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.ide.configuration&apos;, version(&apos;4.2.0.I20120531-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.css.ui&apos;, version(&apos;1.0.700.v201201102037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extensionlocation&apos;, version(&apos;1.2.100.v20110808-1657&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.consumption.infopop&apos;, version(&apos;1.0.300.v200805140230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.telnet.feature.jar&apos;, version(&apos;2.3.0.201205300905-775FD3879AE8MH9BZFP4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.processes.ui&apos;, version(&apos;3.0.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.feature.jar&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.feature.jar&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.runtime&apos;, version(&apos;3.4.300.v20120523-1257&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.persistence.core&apos;, version(&apos;2.4.0.v20120604-r11619&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.debugger.core.ui&apos;, version(&apos;1.0.0.v201003161000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.doc.user&apos;, version(&apos;4.2.0.v20120531-1857&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.dom.svg&apos;, version(&apos;1.1.0.v201011041433&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.core&apos;, version(&apos;1.2.302.v20120503_1042&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.core&apos;, version(&apos;1.1.201.v201203071941&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.ui&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;1.0.300.v20110815-1744&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee&apos;, version(&apos;1.1.600.v201205170400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.http&apos;, version(&apos;8.1.3.v20120522&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.db2.zseries&apos;, version(&apos;1.0.2.v201107221502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.apache.derby&apos;, version(&apos;1.0.102.v201107221459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.generic.jboss&apos;, version(&apos;1.6.1.v200904151730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sybase.ase&apos;, version(&apos;1.0.2.v201201131122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.telnet.feature.jar&apos;, version(&apos;2.1.100.201205300905-308Z312316411A16&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xml.serializer&apos;, version(&apos;2.7.1.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.editor.core&apos;, version(&apos;1.0.2.v201205310904&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.subsystems.processes.dstore&apos;, version(&apos;2.1.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.sqlscrapbook&apos;, version(&apos;1.0.2.v201205310922&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sybase.asa&apos;, version(&apos;1.0.1.v201107221507&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.fproj.enablement.jdt.feature.group&apos;, version(&apos;3.4.0.v201108231500-377DG8s73543J5H6D66&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.feature.jar&apos;, version(&apos;1.1.0.v20120521-2329-8yFTIGF3GGduEYakQB9M3DKn&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.feature.jar&apos;, version(&apos;2.8.0.v20120530-0726&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.bugzilla.core&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.security&apos;, version(&apos;8.1.3.v20120522&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.ui.infopop&apos;, version(&apos;1.0.400.v200805140145&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository.tools&apos;, version(&apos;2.0.100.v20120501-1314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.flatfile&apos;, version(&apos;3.1.2.v201112081200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jaxb.branding&apos;, version(&apos;1.2.0.v201203150000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.ws_userdoc.feature.feature.jar&apos;, version(&apos;3.1.300.v201102200555-44FR79oB5855Q8IBD7G&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.services.local&apos;, version(&apos;2.1.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.editor.core.ui&apos;, version(&apos;1.0.0.v201001150815&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.httpclient&apos;, version(&apos;3.1.0.v201012070820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.ejb.annotations.emitter&apos;, version(&apos;1.1.200.v200909290826&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.garbagecollector&apos;, version(&apos;1.0.200.v20110808-1657&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl.saxon&apos;, version(&apos;1.0.200.v201103081922&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.configuration.feature.group&apos;, version(&apos;1.0.0.I20120531-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.sqlite.feature.feature.group&apos;, version(&apos;1.10.0.v201201161512-542AkF7AJ7SAKAPBF&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.ant&apos;, version(&apos;1.8.3.v20120321-1730&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.binary&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsd.ui&apos;, version(&apos;1.2.500.v201203081826&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.view&apos;, version(&apos;2.3.0.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit&apos;, version(&apos;3.7.100.v20120523-1543&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.ide.ui&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jsf.apache.trinidad.tagsupport.feature.feature.group&apos;, version(&apos;2.2.200.v201105111126-20A77w312215172822&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jpa.eclipselink.feature.feature.group&apos;, version(&apos;3.2.0.v201203150000-7M7J4F7RZHQYIwMsJyOWF5L&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.jca&apos;, version(&apos;1.1.600.v201111012200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.twiki.ui&apos;, version(&apos;1.7.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net&apos;, version(&apos;1.2.200.v20120522-1148&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.servlet&apos;, version(&apos;8.1.3.v20120522&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf&apos;, version(&apos;2.6.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.sqltools.routineeditor.ui&apos;, version(&apos;1.0.2.v201111230714&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.template.ui&apos;, version(&apos;3.2.3.v201201121156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.cxf.ui&apos;, version(&apos;1.0.200.v201203062228&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.cxf.core&apos;, version(&apos;1.1.0.v201205012246&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher&apos;, version(&apos;1.3.0.v20120522-1813&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.hsqldb.dbdefinition&apos;, version(&apos;1.0.0.v201107221502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.discovery.feature.jar&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.ws.axis.consumption.core&apos;, version(&apos;1.0.407.v201104071820&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cvs.feature.jar&apos;, version(&apos;1.3.200.v20120525-1249-7B79FJJAkF7BF7RGE5FAJT&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jpt.jaxb.eclipselink.core&apos;, version(&apos;1.2.0.v201204160000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.feature.group&apos;, version(&apos;3.2.0.201205300905-41-312316411A16&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl.jaxp.launching&apos;, version(&apos;1.0.200.v201103081922&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.ide.ant&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.support.ie&apos;, version(&apos;1.0.401.v201109150330&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.jsdt.support.firefox&apos;, version(&apos;1.0.401.v201109150330&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.ui&apos;, version(&apos;1.0.400.v20120523-2012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.core&apos;, version(&apos;1.2.200.v201205030130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.common.doc.user.feature.jar&apos;, version(&apos;1.10.0.v201201161512-26-311A16321A3557&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery.feature.feature.jar&apos;, version(&apos;1.0.100.v20120524-0542-4-Bh9oB58A5N9L28PCQ&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk.scheduler&apos;, version(&apos;1.1.0.v20110815-1744&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit.feature.group&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.sse.doc.user&apos;, version(&apos;1.1.100.v201005192212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.common.feature.feature.jar&apos;, version(&apos;1.5.0.20120202-1420&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.mysql.ui&apos;, version(&apos;1.0.0.v201109022331&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.core.abc&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.java_feature.feature.jar&apos;, version(&apos;3.8.0.I20120605-2216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsl.feature.feature.group&apos;, version(&apos;1.3.100.v201111021744-7T7ZFUaFIqUoJuvaKoCpQDKaGVPc&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.enablement.ibm.informix.ui&apos;, version(&apos;1.0.3.v201202100836&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.datatools.connectivity.oda.designer.core.feature.feature.jar&apos;, version(&apos;1.10.0.v201201161512-7B7C7LCcNBGTBfLREXcc&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.feature.group&apos;, version(&apos;1.1.0.v20120521-2329-8yFTIGF3GGduEYakQB9M3DKn&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.core&apos;, version(&apos;0.10.1.v20120523-1955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.ssl&apos;, version(&apos;1.0.100.v20120319-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rse.useractions&apos;, version(&apos;1.1.400.201205300905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.powerflasher.fdt.ui.mxml&apos;, version(&apos;1.13.352.1653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient&apos;, version(&apos;4.0.200.v20120319-0616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher&apos;, version(&apos;1.2.0.v20120428-0117&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen&apos;, version(&apos;2.8.0.v20120601-0824&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jem.util&apos;, version(&apos;2.1.100.v201103021400&apos;)]' min='0'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='com.powerflasher.fdt.ui.extension.feature.group' version='1.13.352.1653' singleton='false'>
      <update id='com.powerflasher.fdt.ui.extension.feature.group' range='[0.0.0,1.13.352.1653)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='FDT UI Extension (required)'/>
        <property name='org.eclipse.equinox.p2.description' value='FDT (The Flexible Development Toolkit)'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://fdt.powerflasher.com'/>
        <property name='org.eclipse.equinox.p2.provider' value='Powerflasher, a unit of Interactive Pioneers GmbH'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.powerflasher.fdt.ui.extension.feature.group' version='1.13.352.1653'/>
      </provides>
      <requires size='13'>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.powerflasher.fdt.ui.feature.group' range='[1.13.352.1653,1.13.352.1653]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.powerflasher.fdt.ui.professional.feature.group' range='[1.13.352.1653,1.13.352.1653]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.search' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.editors' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.core.refactoring' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.ui.refactoring' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.powerflasher.fdt.core.enterprise' range='[1.13.352.1653,1.13.352.1653]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.powerflasher.fdt.ui.enterprise' range='[1.13.352.1653,1.13.352.1653]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.powerflasher.fdt.ui.extension.feature.jar' range='[1.13.352.1653,1.13.352.1653]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://fdt.powerflasher.com/eula/' url='http://fdt.powerflasher.com/eula/'>
          ATTENTION:&#xA;YOU WILL NEED TO SCROLL DOWN TO THE END OF THIS EULA BEFORE YOU CAN AGREE TO THE EULA AND CONTINUE WITH THE SOFTWARE INSTALLATION. READ IT CAREFULLY BEFORE COMPLETING THE INSTALLATION AND USING THE SOFTWARE.&#xA;IMPORTANT:&#xA;1. This contract (EULA = End User&apos;s License Agreement), is a legally binding agreement between the Person, Company or Organization that has licensed this Software (Customer), and Interactive Pioneers GmbH, unit Powerflasher (POWERFLASHER).&#xA;2. By installing and using the software, the customer accepts and agrees to the terms of this contract. Use of the software is legally equivalent to agreeing to the terms and conditions of this license.&#xA;&#xA;3. If you do not agree to this EULA, or if you do not have the authority to agree to this EULA on the customer&apos;s behalf, do not install or use the software, and return the software within 14 days for a full refund to your vendor, in accordance with vendor&apos;s general refund policies (Terms and Conditions).&#xA;&#xA;&#xA;4. This EULA only applies to the software supplied by POWERFLASHER through this download or delivery, regardless of any other software described in this document.&#xA;&#xA;§1 Applicability of Contract&#xA;&#xA;1. This contract applies to the licensing of one copy of the FDT software, including the FDT Manual, by POWERFLASHER.&#xA;2. This contract does not apply to installation and post-installation service. This includes hardware and software service of any kind.&#xA;&#xA;§2 Duties of POWERFLASHER&#xA;&#xA;1. POWERFLASHER is obliged to provide a copy of FDT by download, according to §1 of this contract.&#xA;2. POWERFLASHER is obliged to provide a copy of the FDT Manual as a digital *.document by download to the customer.&#xA;&#xA;§3 Terms of Use&#xA;&#xA;1. Customer may only copy the supplied software inasmuch as the copy is essential for using the program. Essential copies are such from original data carrier to customer&apos;s hard drive, and into the RAM memory of customer&apos;s hardware.&#xA;2. POWERFLASHER permits the customer to make one backup copy of FDT. Customer is not allowed to sell the backup copy, or to pass on the backup copy to a third party.&#xA;3. Customer is not allowed to use the Software on a network that allows more than one person to work with this software at the same time, unless customer provides each person with a licensed copy.&#xA;4. This EULA allows the customer to install the software only once on a single computer. If the customer wants to use the licensed copy of FDT on different hardware, he must remove the software from the former hardware before starting the installation process.&#xA;5. Exception: Customer may employ an additional copy of the software on a second, portable device for the exclusive use of the primary user of the copy of the software.&#xA;6. Customer is not allowed to use this FDT License on several hardware systems at the same time.&#xA;7. Customer is not allowed to make copies of the FDT Manual. If the FDT Manual is a digital *.document, the customer may make one backup copy.&#xA;8. The software may only be transferred to a third party if this party agrees with the conditions of this EULA. All FDT copies must be handed over to the third party, including any backup copies, and the FDT Manuals. The right of the customer to use the FDT Software expires with handing over the FDT software to the third party or person. Customer must remove all copies of the FDT software from any hard drives.&#xA;9. In case the software is transferred to a third person or party, customer must inform POWERFLASHER of the name and legal address of the third party, in writing (§126b German Civil Code BGB).&#xA;10. The right to pass on the software to third parties is void  if reasonable suspicion exists the third party will violate these contract terms and conditions, or the copyrights of the supplier.&#xA;11. Customer  agrees that POWERFLASHER may, within a reasonable notification period, seek to verify that software use is in compliance with these terms and conditions. Should this verification show that use of the software is not in compliance with this contract, customer is obliged to reimburse verification expenses, in addition to any claims by POWERFLASHER that may arise from violation of terms and conditions.&#xA;&#xA;§ 4 Customer Responsibilities&#xA;&#xA;1. Customer is obliged to take sufficient measures to prevent unauthorized third parties from gaining illicit access to this software. Original data carriers and backup copies must be stored secure from illicit access by third parties. Customer&apos;s employees must be made aware of the terms and conditions of this contract, and POWERFLASHER&apos;s copyrights.&#xA;2. Customer may not attempt to alter the software in any way. Customer may not attempt to change, combine, adjust, translate, or disassemble it, or make visual representations thereof.&#xA;3. Customer is not permitted to rent, loan or sublicense software without express written consent by POWERFLASHER.&#xA;4. Furthermore, customer is not permitted to retranslate licensed program code into other forms  of code (decompiling).&#xA;5. Customer is not permitted to remove attributes that serve to safeguard POWERFLASHER&apos;s copyright, or that serve to prevent illicit copying.&#xA;&#xA;§ 5 Examination and Complaints&#xA;&#xA;1. Customer must examine provided software and manual within two weeks of receipt, in particularly as regards intactness of software and manual, as well as the working of basic software functions. Complaints that are evident or result from this examination must be reported to manufacturer within one additional week in writing (German Civil Code BGB, § 126b). A detailed description of the defect is required.&#xA;2. Defects to software or manual not evident in the course of this examination as required in Paragraph 1 above, must be communicated within one week of discovery, in writing  (German Civil Code BGB, § 126b).&#xA;3. Should these responsibilities to examine and report defects be violated, any defect is held to be approved by customer.&#xA;&#xA;§ 6 Limited Warranty and Liability&#xA;&#xA;1. Manufacturer&apos;s liability for product defects is regulated by German commercial law alone (German Civil Code BGB, § 434 and following).&#xA;2. POWERFLASHER&apos;s liability (pre-contractual, contractual and extra-contractual) is limited to deliberate and gross negligence. This liability limitation applies to liabilities of third-party vendors employed by manufacturer as well.&#xA;&#xA;§ 7 Terms of Payment and Reservation of Proprietary Rights&#xA;&#xA;1. After delivery of the software in question, payment is due to POWERFLASHER as invoiced to the customer. Invoice includes German sales tax and is payable within 10 working days.&#xA;2. POWERFLASHER retains property of software delivered to customer until receipt of full payment as contractually agreed (German Civil Code BGB, § 7 1st Sentence).&#xA;3. Should customer violate terms of payment, invocation of property rights does not imply cancellation of contract unless expressly stated by POWERFLASHER to customer.&#xA;4. Should POWERFLASHER invoke retention of property rights, the right to continued use of software in question by customer is waived. All copies of software made by customer must be removed.&#xA;&#xA;§ 8 Upgrade&#xA;1. Insofar as the software is an upgrade of an earlier version of the software, customer must possess a valid license for the existing earlier full version in order to install or use said upgrade.&#xA;2. Insofar as customer received a rebate for the upgrade based on an existing earlier license, software is to be provided as a license exchange. By installing and using the upgrade, customer agrees to end the existing prior EULA and refrain from reinstalling the previous licensed version of the software, or transferring it to other natural or corporate persons.&#xA;3. Customer may continue using the earlier software version, for which the upgrade in question was obtained, if the upgrade and the copy of the earlier version are both installed on the same computer, and if the earlier version is not installed on another computer.&#xA;4. Customer acknowledges that POWERFLASHER&apos;s obligation to support earlier software versions ends with the availability of an upgrade.&#xA;&#xA;§ 9 Additional Agreement for Non-EU Citizens&#xA;1. EXCEPT AS SET FORTH IN THE FOREGOING LIMITED WARRANTY WITH RESPECT TO SOFTWARE, POWERFLASHER AND ITS SUPPLIERS DISCLAIM ALL OTHER WARRANTIES AND LIABILITIES.&#xA;2. POWERFLASHER IS NOT LIABLE OR RESPONSIBLE (WHETHER EXPRESS, IMPLIED, OR OTHERWISE) FOR MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. ALSO, THERE IS NO WARRANTY OF NON-INFRINGEMENT AND TITLE, OR QUIET ENJOYMENT.&#xA;3. POWERFLASHER DOES NOT WARRANT THAT THE SOFTWARE IS ERROR-FREE OR WILL OPERATE WITHOUT INTERRUPTION.&#xA;4. NO RIGHTS OR REMEDIES REFERRED TO IN ARTICLE 2A OF THE UCC UNIFORM COMMERCIAL CODE), WILL BE CONFERRED UNLESS EXPRESSLY GRANTED HEREIN FROM POWERFLASHER.&#xA;5. THE SOFTWARE IS NOT DESIGNED, INTENDED OR LICENSED FOR USE IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE CONTROLS, INCLUDING, WITHOUT LIMITATION, THE DESIGN, CONSTRUCTION, MAINTENANCE OR OPERATION OF NUCLEAR FACILITIES, AIRCRAFT NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL, AND LIFE SUPPORT OR WEAPONS SYSTEMS. POWERFLASHER SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR SUCH PURPOSES.&#xA;6. IF APPLICABLE LAW REQUIRES ANY WARRANTIES WITH RESPECT TO THE SOFTWARE, ALL SUCH WARRANTIES ARE LIMITED IN DURATION TO NINETY (90) DAYS FROM THE DATE OF DELIVERY.&#xA;7. NO ORAL OR WRITTEN INFORMATION GIVEN BY POWERFLASHER, ITS DEALERS, DISTRIBUTORS OR EMPLOYEES SHALL CREATE A WARRANTY OR IN ANY WAY INCREASE THE SCOPE OF ANY WARRANTY PROVIDED HEREIN.&#xA;8. NEITHER POWERFLASHER NOR ITS SUPPLIERS SHALL BE LIABLE TO CUSTOMER OR ANY THIRD PARTY FOR ANY INDIRECT OR CONSEQUENTIAL DAMAGES OR CIVIL PENALTY (INCLUDING, BUT NOT LIMITED TO, DAMAGES FOR THE INABILITY TO USE EQUIPMENT OR ACCESS DATA, LOSS OF BUSINESS,  BUSINESS INTERRUPTION OR THE LIKE), ARISING OUT OF THE USE OF THE SOFTWARE AND BASED ON ANY THEORY OF LIABILITY, INCLUDING BREACH OF CONTRACT, BREACH OF WARRANTY, TORT, PRODUCT LIABILITY OR OTHERWISE.&#xA;9. POWERFLASHER&apos;S TOTAL LIABILITY TO CUSTOMER FOR DAMAGES – FOR ANY CAUSE - WILL BE LIMITED TO THE AMOUNT PAID BY CUSTOMER FOR THE SOFTWARE.&#xA;10. THIS EULA IS FUNDAMENTAL ELEMENT OF THE AGREEMENT BETWEEN POWERFLASHER AND CUSTOMER.  POWERFLASHER WOULD NOT BE ABLE TO PROVIDE THE SOFTWARE ON AN ECONOMIC BASIS WITHOUT SUCH LIMITATIONS. SUCH LIMITED WARRANTY AND LIMITED LIABILITY INURE TO THE BENEFIT OF THE CUSTOMER.&#xA;&#xA;§ 10 Final Regulations&#xA;&#xA;1. This contract is subject to German law only. The application of the UN convention on contracts for the purchase of goods is excluded.&#xA;2. The exclusive place of jurisdiction for all disputes arising out of or in conjunction with this contract is Aachen, Germany.&#xA;3. Should one of the provisions of this contract be found void, the applicability of the other provisions will not be affected. The parties undertake to replace void provisions with others that are best suited to the commercial purpose intended by the parties.&#xA;4. All questions concerning this EULA shall be directed to: Interactive Pioneers GmbH, Belvedereallee 5, 52070 Aachen, Germany, e-mail: welcome@interactive-pioneers.de.&#xA;5. This contract is a translation of the German original, which alone is legally binding.&#xA;&#xA;§ 11 Supplementary Agreement for POWERFLASHER FDT University Program&#xA;&#xA;This supplementary agreement (referred to herein as &quot;agreement&quot;) is a legally binding contract between Interactive Pioneers GmbH, unit Powerflasher (referred to herein as &quot;POWERFLASHER&quot;) and an accredited educational institution  (referred to herein as &quot;licensee“), approved by  Powerflasher to participate in the Powerflasher FDT University Program.&#xA;The FDT University Program permits licensee to use proprietary software for non-profit purposes.&#xA;By installing and using this software, licensee agrees to the terms and conditions of this agreement. Using the software is equated with agreeing to this contract and taken as declaration of consent.&#xA;Licensees who do not agree with the terms of this agreement, or are not entitled to give such consent, may not install or use the software.&#xA;&#xA;1. Definitions&#xA;1.1 &quot;Faculty&quot; refers to personnel officially assigned to teach students, or conduct research, by the licensee.&#xA;1.2 &quot;Software&quot; is defined as in the End User License Agreement EULA.&#xA;1.3 &quot;Student&quot; refers to a student currently officially registered for study with licensee.&#xA;1.4 &quot;Use&quot; refers to non-commercial use of Software by faculty, personnel or students for the following purposes only:&#xA; a) to develop, support and conduct lectures, seminars, workshops or similar programs conducted by licensee;&#xA; b) to conduct non-commercial research projects using the software, or to design, develop and present software or hardware that interacts with the licensed Software.&#xA;1.5. &quot;Use&quot; as part of this agreement does not apply to commercial use of Software by any students or employees of licensee.&#xA;2. License for Use in Research and Teaching.&#xA;POWERFLASHER grants the licensee a non-exclusive license, subject to the EULA above and this supplementary agreement:&#xA;(a) To install all software available as part of the Powerflasher FDT University Program on any number of servers, personal computers, or laptops within the facilities of licensee.&#xA;(b) To install all software on the personal computers and laptops of faculty and students outside the facilities, as long as its use is limited exclusively to aforementioned purposes as defined under 1.4 and 1.5 above.&#xA;Software on computers and laptops of faculty, personnel and students may not be copied or made available to third parties.&#xA;Licensee is responsible for procuring the consent of faculty, personnel and students to adhere to the provisions of the EULA and this agreement.&#xA;Licensee must keep a record of downloads of Software from its servers, and provide this data to POWERFLASHER on request.&#xA;Licensee may not provide Software to faculty, personnel and students who are no longer employed or registered.&#xA;Should licensee gain knowledge of faculty, personnel and students violating the EULA or this agreement, he is required to prevent further access by such violators to the Software. He must undertake all reasonable efforts to retract the Software in the possession of such violators and  delete it.&#xA;Licensee agrees to undertake all reasonable steps to prevent use of, and access to the Software by unauthorized parties.&#xA;Licensee is not entitled to resell, rent, lease or otherwise transfer the Software to third parties. All rights not explicitly granted in this agreement remain reserved to Powerflasher.&#xA;In some cases, licensee may require a Product Key (&quot;Volume License Key&quot;). The Volume License Key is issued to licensee and must be kept safe. Licensee may make the Volume License Key available only to staff concerned with software support and administration. Licensee is liable for all damages resulting from unauthorized use of the Volume License Key.&#xA;3. Final Provisions&#xA;Any violations of the terms and conditions of the EULA and the supplementary agreement by the licensee are subject to damages to POWERFLASHER according to German law.&#xA;Should licensee cancel his participation in the Powerflasher FDT University Program, or have his participation in the Powerflasher FDT University Program terminated by Powerflasher, licensee may no longer make the Software available to faculty, personnel or students.&#xA;&#xA;&#xA;The Author:&#xA;&#xA;Interactive Pioneers GmbH&#xA;Belvedereallee 5&#xA;52070 Aachen&#xA;Germany&#xA;http://www.powerflasher.com&#xA;&#xA;&#xA;About Interactive Pioneers GmbH Germany&#xA;-------------------------------&#xA;POWERFLASHER develops multimedia applications and is with over 500 references one of the leading European supplier for Macromedia Flash solutions.  The team of 15 specialists has positioned itself as a service provider for creative and technological innovative Flash content with clients like AOL, Bayer AG, Dell, Lycos, Microsoft and many more.&#xA;POWERFLASHER is focused on creating Flash applications, RIAs, games (more than 150 game-references), WBTs and everything whats possible with Macromedia Flash.
        </license>
      </licenses>
      <copyright uri='http://fdt.powerflasher.com' url='http://fdt.powerflasher.com'>
        © Copyright 2012 Powerflasher, a unit of Interactive Pioneers GmbH
      </copyright>
    </unit>
    <unit id='epp.package.jee' version='1.5.0.20120602-0806'>
      <update id='epp.package.jee' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='Eclipse IDE for Java EE Developers'/>
        <property name='lineUp' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='epp.package.jee' version='1.5.0.20120602-0806'/>
      </provides>
      <requires size='9'>
        <required namespace='org.eclipse.equinox.p2.iu' name='config.a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingepp.package.jee.configuration' range='[1.5.0.20120602-0806,1.5.0.20120602-0806]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingepp.package.jee.application' range='[1.5.0.20120602-0806,1.5.0.20120602-0806]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.ide' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.package.jee.feature.feature.group' range='[1.5.0.20120602-0806,1.5.0.20120602-0806]'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='unconfigure'>
            org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:0,location:http${#58}//download.eclipse.org/webtools/repository/juno);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:1,location:http${#58}//download.eclipse.org/webtools/repository/juno);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:0,location:http${#58}//download.eclipse.org/mylyn/releases/juno);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:1,location:http${#58}//download.eclipse.org/mylyn/releases/juno);
          </instruction>
          <instruction key='configure'>
            org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:0,location:http${#58}//download.eclipse.org/webtools/repository/juno,name:The Eclipse Web Tools Platform (WTP) software repository);org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:1,location:http${#58}//download.eclipse.org/webtools/repository/juno,name:The Eclipse Web Tools Platform (WTP) software repository);org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:0,location:http${#58}//download.eclipse.org/mylyn/releases/juno,name:Mylyn for Eclipse Juno);org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:1,location:http${#58}//download.eclipse.org/mylyn/releases/juno,name:Mylyn for Eclipse Juno);
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='license.html' url='license.html'>
          ECLIPSE FOUNDATION SOFTWARE USER AGREEMENT\n\&#xA;June, 2010\n\&#xA;\n\&#xA;Usage Of Content\n\&#xA;\n\&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR\n\&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).\n\&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS\n\&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR\n\&#xA;NOTICES INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU\n\&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT\n\&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS\n\&#xA;OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE\n\&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS\n\&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED\n\&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.\n\&#xA;\n\&#xA;Applicable Licenses\n\&#xA;\n\&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation\n\&#xA;is provided to you under the terms and conditions of the Eclipse Public\n\&#xA;License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is provided with this\n\&#xA;Content and is also available at http://www.eclipse.org/legal/epl-v10.html.\n\&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.\n\&#xA;\n\&#xA;Content includes, but is not limited to, source code, object code,\n\&#xA;documentation and other files maintained in the Eclipse.org CVS\n\&#xA;repository (&quot;Repository&quot;) in CVS modules (&quot;Modules&quot;) and made available\n\&#xA;as downloadable archives (&quot;Downloads&quot;).\n\&#xA;\n\&#xA;   - Content may be structured and packaged into modules to facilitate delivering,\n\&#xA;     extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),\n\&#xA;     plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).\n\&#xA;   - Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java? ARchive)\n\&#xA;     in a directory named &quot;plugins&quot;.\n\&#xA;   - A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.\n\&#xA;     Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.\n\&#xA;     Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version\n\&#xA;     numbers of the Plug-ins and/or Fragments associated with that Feature.\n\&#xA;   - Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files\n\&#xA;     named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.\n\&#xA;\n\&#xA;Features may also include other Features (&quot;Included Features&quot;). Files named\n\&#xA;&quot;feature.xml&quot; may contain a list of the names and version numbers of\n\&#xA;Included Features.\n\&#xA;\n\&#xA;The terms and conditions governing Plug-ins and Fragments should be\n\&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and\n\&#xA;conditions governing Features and Included Features should be contained\n\&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature\n\&#xA;Licenses may be located in any directory of a Download or Module\n\&#xA;including, but not limited to the following locations:\n\&#xA;\n\&#xA;   - The top-level (root) directory\n\&#xA;   - Plug-in and Fragment directories\n\&#xA;   - Inside Plug-ins and Fragments packaged as JARs\n\&#xA;   - Sub-directories of the directory named &quot;src&quot; of certain Plug-ins\n\&#xA;   - Feature directories\n\&#xA;\n\&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the\n\&#xA;Eclipse Update Manager, you must agree to a license (&quot;Feature Update\n\&#xA;License&quot;) during the installation process. If the Feature contains\n\&#xA;Included Features, the Feature Update License should either provide you\n\&#xA;with the terms and conditions governing the Included Features or inform\n\&#xA;you where you can locate them. Feature Update Licenses may be found in\n\&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot;. Such Abouts,\n\&#xA;Feature Licenses and Feature Update Licenses contain the terms and\n\&#xA;conditions (or references to such terms and conditions) that govern your\n\&#xA;use of the associated Content in that directory.\n\&#xA;\n\&#xA;THE ABOUTS, FEATURE LICENSES AND FEATURE UPDATE LICENSES MAY REFER\n\&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.\n\&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):\n\&#xA;\n\&#xA;    - Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)\n\&#xA;    - Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)\n\&#xA;    - Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)\n\&#xA;    - IBM Public License 1.0 (available at http://oss.software.ibm.com/developerworks/opensource/license10.html)\n\&#xA;    - Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)\n\&#xA;    - Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)\n\&#xA;    - Common Development and Distribution License (CDDL) Version 1.0 (available at http://www.sun.com/cddl/cddl.html)\n\&#xA;\n\&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR\n\&#xA;TO USE OF THE CONTENT. If no About, Feature License or Feature Update License\n\&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions\n\&#xA;govern that particular Content.\n\&#xA;\n\&#xA;Cryptography\n\&#xA;\n\&#xA;Content may contain encryption software. The country in which you are\n\&#xA;currently may have restrictions on the import, possession, and use,\n\&#xA;and/or re-export to another country, of encryption software. BEFORE\n\&#xA;using any encryption software, please check the country&apos;s laws,\n\&#xA;regulations and policies concerning the import, possession, or use,\n\&#xA;and re-export of encryption software, to see if this is permitted.\n\&#xA;\n\&#xA;Java and all Java-based trademarks are trademarks of Sun Microsystems, Inc. in the United States, other countries, or both.\n
        </license>
      </licenses>
    </unit>
    <unit id='org.eclipse.cvs_root' version='1.3.200.v20120525-1249-7B79FJJAkF7BF7RGE5FAJT'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cvs_root' version='1.3.200.v20120525-1249-7B79FJJAkF7BF7RGE5FAJT'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.cvs_root' version='1.3.200.v20120525-1249-7B79FJJAkF7BF7RGE5FAJT'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jdt_root' version='3.8.0.v20120525-1249-8-8nFqlFNOfwKDRF3dXMdHyBC834'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt_root' version='3.8.0.v20120525-1249-8-8nFqlFNOfwKDRF3dXMdHyBC834'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.jdt_root' version='3.8.0.v20120525-1249-8-8nFqlFNOfwKDRF3dXMdHyBC834'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.platform_root' version='4.2.0.v20120528-1648-9JF7BHV8FyMteji0MoOeOuU6sAnxIeYtKNM1dK'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform_root' version='4.2.0.v20120528-1648-9JF7BHV8FyMteji0MoOeOuU6sAnxIeYtKNM1dK'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.platform_root' version='4.2.0.v20120528-1648-9JF7BHV8FyMteji0MoOeOuU6sAnxIeYtKNM1dK'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.rcp.configuration_root.cocoa.macosx.x86_64' version='1.0.0.I20120531-1500'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.cocoa.macosx.x86_64' version='1.0.0.I20120531-1500'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.rcp.configuration_root.cocoa.macosx.x86_64' version='1.0.0.I20120531-1500'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='3'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
        <instructions size='1'>
          <instruction key='configure'>
            ln(linkTarget:Eclipse.app/Contents/MacOS/eclipse,targetDir:${installFolder},linkName:eclipse);
          </instruction>
        </instructions>
        <instructions size='1'>
          <instruction key='install'>
            chmod(targetDir:${installFolder}, targetFile:Eclipse.app/Contents/MacOS/eclipse, permissions:755);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.rcp_root' version='4.2.0.v20120528-1648-7IAPA7BrHQicRoQXOz0Obz-blRCA'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp_root' version='4.2.0.v20120528-1648-7IAPA7BrHQicRoQXOz0Obz-blRCA'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.rcp_root' version='4.2.0.v20120528-1648-7IAPA7BrHQicRoQXOz0Obz-blRCA'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='8'>
    <iuProperties id='SharedProfile_epp.package.jee' version='1.0.0.1377607131589'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='com.powerflasher.fdt.ui.extension.feature.group' version='1.13.352.1653'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='epp.package.jee' version='1.5.0.20120602-0806'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.cvs_root' version='1.3.200.v20120525-1249-7B79FJJAkF7BF7RGE5FAJT'>
      <properties size='3'>
        <property name='unzipped|@artifact|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse' value='/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/notice.html|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/epl-v10.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.jdt_root' version='3.8.0.v20120525-1249-8-8nFqlFNOfwKDRF3dXMdHyBC834'>
      <properties size='3'>
        <property name='unzipped|@artifact|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse' value='/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/epl-v10.html|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/notice.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.platform_root' version='4.2.0.v20120528-1648-9JF7BHV8FyMteji0MoOeOuU6sAnxIeYtKNM1dK'>
      <properties size='3'>
        <property name='unzipped|@artifact|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse' value='/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/notice.html|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/epl-v10.html|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/readme|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/readme/readme_eclipse.html|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/.eclipseproduct|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.rcp.configuration_root.cocoa.macosx.x86_64' version='1.0.0.I20120531-1500'>
      <properties size='3'>
        <property name='unzipped|@artifact|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse' value='/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/Eclipse.app|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/Eclipse.app/Contents|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/Eclipse.app/Contents/Info.plist|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/Eclipse.app/Contents/Resources|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/Eclipse.app/Contents/Resources/Eclipse.icns|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/Eclipse.app/Contents/MacOS|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/Eclipse.app/Contents/MacOS/eclipse|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.rcp_root' version='4.2.0.v20120528-1648-7IAPA7BrHQicRoQXOz0Obz-blRCA'>
      <properties size='3'>
        <property name='unzipped|@artifact|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse' value='/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/readme|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/readme/readme_eclipse.html|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/notice.html|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/.eclipseproduct|/shared/technology/epp/epp_build/juno/build/epp.package.jee/macosx.cocoa.x86_64/eclipse/epl-v10.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
